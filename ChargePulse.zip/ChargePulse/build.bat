@echo off
setlocal
cd /d "%~dp0"
call setup.bat
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD FAILED
  exit /b 1
)
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
endlocal
