package com.veus.chargepulse.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public final class SessionDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "chargepulse.db";
    private static final int DB_VERSION = 1;
    private static final String COLS =
            "id,type,label,start_ms,end_ms,start_level,end_level,avg_ma,peak_ma,avg_temp,max_temp,avg_w";

    private static SessionDb instance;

    public static synchronized SessionDb get(Context c) {
        if (instance == null) instance = new SessionDb(c.getApplicationContext());
        return instance;
    }

    private SessionDb(Context c) {
        super(c, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "type INTEGER NOT NULL,"
                + "label TEXT,"
                + "start_ms INTEGER NOT NULL,"
                + "end_ms INTEGER NOT NULL,"
                + "start_level INTEGER,"
                + "end_level INTEGER,"
                + "avg_ma REAL,"
                + "peak_ma REAL,"
                + "avg_temp REAL,"
                + "max_temp REAL,"
                + "avg_w REAL)");
        db.execSQL("CREATE INDEX idx_sessions_start ON sessions(start_ms)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 only. Add migrations here when the schema changes.
    }

    public synchronized long insert(Session s) {
        ContentValues v = new ContentValues();
        v.put("type", s.type);
        v.put("label", s.label);
        v.put("start_ms", s.startMs);
        v.put("end_ms", s.endMs);
        v.put("start_level", s.startLevel);
        v.put("end_level", s.endLevel);
        v.put("avg_ma", s.avgMa);
        v.put("peak_ma", s.peakMa);
        v.put("avg_temp", s.avgTempC);
        v.put("max_temp", s.maxTempC);
        v.put("avg_w", s.avgPowerW);
        long id = getWritableDatabase().insert("sessions", null, v);
        trim(500);
        return id;
    }

    /** Keeps the table from growing without limit. */
    private void trim(int keep) {
        getWritableDatabase().execSQL("DELETE FROM sessions WHERE id NOT IN "
                + "(SELECT id FROM sessions ORDER BY start_ms DESC LIMIT " + keep + ")");
    }

    public synchronized List<Session> list(int limit) {
        List<Session> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT " + COLS + " FROM sessions ORDER BY start_ms DESC LIMIT " + limit, null);
        try {
            while (c.moveToNext()) out.add(read(c));
        } finally {
            c.close();
        }
        return out;
    }

    public synchronized Session bestTest() {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT " + COLS + " FROM sessions WHERE type=" + Session.TEST
                        + " ORDER BY avg_ma DESC LIMIT 1", null);
        try {
            return c.moveToFirst() ? read(c) : null;
        } finally {
            c.close();
        }
    }

    public synchronized void delete(long id) {
        getWritableDatabase().delete("sessions", "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized void clear() {
        getWritableDatabase().delete("sessions", null, null);
    }

    private static Session read(Cursor c) {
        Session s = new Session();
        s.id = c.getLong(0);
        s.type = c.getInt(1);
        s.label = c.isNull(2) ? "" : c.getString(2);
        s.startMs = c.getLong(3);
        s.endMs = c.getLong(4);
        s.startLevel = c.getInt(5);
        s.endLevel = c.getInt(6);
        s.avgMa = c.getFloat(7);
        s.peakMa = c.getFloat(8);
        s.avgTempC = c.getFloat(9);
        s.maxTempC = c.getFloat(10);
        s.avgPowerW = c.getFloat(11);
        return s;
    }
}
