package com.veus.chargepulse.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.veus.chargepulse.R;
import com.veus.chargepulse.battery.BatteryReader;
import com.veus.chargepulse.battery.BatterySample;
import com.veus.chargepulse.battery.SampleStore;
import com.veus.chargepulse.data.Prefs;
import com.veus.chargepulse.service.MonitorService;

public class LiveFragment extends Fragment {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BatteryReader reader;
    private Prefs prefs;

    private TextView tvState, tvCurrent, tvPower, tvVoltage, tvTemp, tvLevel, tvEta;
    private TextView tvPeak, tvAvg, tvHealth, tvWarn;
    private LineChartView chart;
    private Button btnMonitor;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!isAdded() || getView() == null) return;
            if (!MonitorService.isRunning()) {
                SampleStore.add(reader.read());
            }
            render();
            handler.postDelayed(this, prefs.intervalSec() * 1000L);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_live, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        Context c = requireContext();
        reader = new BatteryReader(c);
        prefs = new Prefs(c);

        tvState = v.findViewById(R.id.tvState);
        tvCurrent = v.findViewById(R.id.tvCurrent);
        tvPower = v.findViewById(R.id.tvPower);
        tvVoltage = v.findViewById(R.id.tvVoltage);
        tvTemp = v.findViewById(R.id.tvTemp);
        tvLevel = v.findViewById(R.id.tvLevel);
        tvEta = v.findViewById(R.id.tvEta);
        tvPeak = v.findViewById(R.id.tvPeak);
        tvAvg = v.findViewById(R.id.tvAvg);
        tvHealth = v.findViewById(R.id.tvHealth);
        tvWarn = v.findViewById(R.id.tvWarn);
        chart = v.findViewById(R.id.chart);
        btnMonitor = v.findViewById(R.id.btnMonitor);

        btnMonitor.setOnClickListener(b -> toggleMonitor());
        v.findViewById(R.id.btnReset).setOnClickListener(b -> {
            SampleStore.resetStats();
            render();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        updateMonitorButton();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    public void onPause() {
        handler.removeCallbacksAndMessages(null);
        super.onPause();
    }

    private void toggleMonitor() {
        Context c = requireContext();
        Intent it = new Intent(c, MonitorService.class);
        if (MonitorService.isRunning()) {
            c.stopService(it);
        } else {
            ContextCompat.startForegroundService(c, it);
        }
        handler.postDelayed(this::updateMonitorButton, 500L);
    }

    private void updateMonitorButton() {
        if (btnMonitor == null) return;
        btnMonitor.setText(MonitorService.isRunning()
                ? R.string.btn_monitor_stop : R.string.btn_monitor_start);
    }

    private void render() {
        if (!isAdded() || getView() == null) return;
        Context c = requireContext();

        BatterySample s = SampleStore.latest();
        if (s == null) {
            s = reader.read();
            SampleStore.add(s);
        }

        if (s.isPlugged()) {
            tvState.setText(getString(R.string.state_plugged,
                    Fmt.plugged(c, s.plugged), Fmt.status(c, s.status)));
        } else {
            tvState.setText(R.string.state_discharging);
        }

        int color;
        if (!s.currentSupported) {
            color = ContextCompat.getColor(c, R.color.cp_dim);
        } else if (s.isPlugged()) {
            color = ContextCompat.getColor(c,
                    s.currentMa >= prefs.slowMa() ? R.color.cp_green : R.color.cp_amber);
        } else {
            color = ContextCompat.getColor(c,
                    -s.currentMa > prefs.drainMa() ? R.color.cp_red : R.color.cp_cyan);
        }

        tvCurrent.setTextColor(color);
        tvCurrent.setText(s.currentSupported ? Fmt.ma(s.currentMa) : getString(R.string.not_available));
        tvPower.setText(s.currentSupported ? Fmt.watts(s.powerW()) : getString(R.string.not_available));
        tvVoltage.setText(Fmt.volts(s.voltageMv));
        tvTemp.setText(Fmt.temp(s.tempC));
        tvLevel.setText(s.level >= 0 ? s.level + "%" : getString(R.string.not_available));

        float hours = SampleStore.etaHours();
        if (hours < 0f) {
            tvEta.setText(R.string.not_available);
        } else if (s.isPlugged()) {
            tvEta.setText(getString(R.string.eta_full, Fmt.eta(c, hours)));
        } else {
            tvEta.setText(getString(R.string.eta_empty, Fmt.eta(c, hours)));
        }

        chart.setData(SampleStore.currents(), color);
        tvPeak.setText(Fmt.maAbs(SampleStore.peakMa()));
        tvAvg.setText(Fmt.ma(SampleStore.avgMa()));

        String cycles = s.cycles > 0 ? String.valueOf(s.cycles) : "\u2014";
        tvHealth.setText(getString(R.string.health_line, Fmt.health(c, s.health), cycles));

        if (!s.currentSupported) {
            tvWarn.setText(R.string.warn_unsupported);
            tvWarn.setVisibility(View.VISIBLE);
        } else if (s.isPlugged() && SampleStore.zeroCurrentStreak() >= 10) {
            tvWarn.setText(R.string.warn_zero);
            tvWarn.setVisibility(View.VISIBLE);
        } else {
            tvWarn.setVisibility(View.GONE);
        }
    }
}
