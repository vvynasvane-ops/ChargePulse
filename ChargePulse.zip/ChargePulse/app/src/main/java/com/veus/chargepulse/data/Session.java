package com.veus.chargepulse.data;

public final class Session {
    public static final int CHARGE = 0, DISCHARGE = 1, TEST = 2;

    public long id;
    public int type;
    public String label = "";
    public long startMs;
    public long endMs;
    public int startLevel;
    public int endLevel;
    public float avgMa;
    public float peakMa;
    public float avgTempC;
    public float maxTempC;
    public float avgPowerW;
}
