package com.veus.chargepulse.battery;

import android.os.BatteryManager;

public final class BatterySample {
    public final long timeMs;
    /** Normalised current in mA. Positive = into the battery, negative = out of it. */
    public final float currentMa;
    public final long rawCurrent;
    public final int voltageMv;
    public final float tempC;
    public final int level;
    public final int status;
    public final int plugged;
    public final int health;
    public final int cycles;
    /** Battery charge counter in microamp-hours, or -1 when unavailable. */
    public final long chargeUah;
    public final boolean currentSupported;

    public BatterySample(long timeMs, float currentMa, long rawCurrent, int voltageMv, float tempC,
                         int level, int status, int plugged, int health, int cycles,
                         long chargeUah, boolean currentSupported) {
        this.timeMs = timeMs;
        this.currentMa = currentMa;
        this.rawCurrent = rawCurrent;
        this.voltageMv = voltageMv;
        this.tempC = tempC;
        this.level = level;
        this.status = status;
        this.plugged = plugged;
        this.health = health;
        this.cycles = cycles;
        this.chargeUah = chargeUah;
        this.currentSupported = currentSupported;
    }

    /** mA x mV = microwatts, so divide by 1,000,000 for watts. */
    public float powerW() {
        return Math.abs(currentMa) * voltageMv / 1_000_000f;
    }

    public boolean isPlugged() {
        return plugged != 0;
    }

    public boolean isCharging() {
        return status == BatteryManager.BATTERY_STATUS_CHARGING;
    }
}
