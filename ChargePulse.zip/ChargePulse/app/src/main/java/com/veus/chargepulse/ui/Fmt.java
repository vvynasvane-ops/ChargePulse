package com.veus.chargepulse.ui;

import android.content.Context;
import android.os.BatteryManager;

import com.veus.chargepulse.R;

import java.util.Locale;

public final class Fmt {
    private Fmt() { }

    public static String ma(float v) {
        return String.format(Locale.US, "%+,.0f mA", v);
    }

    public static String maAbs(float v) {
        return String.format(Locale.US, "%,.0f mA", Math.abs(v));
    }

    public static String watts(float w) {
        return String.format(Locale.US, "%.2f W", w);
    }

    public static String volts(int mv) {
        return String.format(Locale.US, "%.2f V", mv / 1000f);
    }

    public static String temp(float c) {
        return String.format(Locale.US, "%.1f \u00B0C", c);
    }

    public static String duration(long ms) {
        long s = ms / 1000L;
        if (s < 60) return s + " s";
        long m = s / 60;
        if (m < 60) return m + " min";
        return (m / 60) + " h " + (m % 60) + " min";
    }

    public static String eta(Context c, float hours) {
        int minutes = Math.round(hours * 60f);
        if (minutes < 60) return c.getString(R.string.time_min, Math.max(minutes, 1));
        return c.getString(R.string.time_h_min, minutes / 60, minutes % 60);
    }

    public static String status(Context c, int status) {
        switch (status) {
            case BatteryManager.BATTERY_STATUS_CHARGING: return c.getString(R.string.status_charging);
            case BatteryManager.BATTERY_STATUS_DISCHARGING: return c.getString(R.string.status_discharging);
            case BatteryManager.BATTERY_STATUS_FULL: return c.getString(R.string.status_full);
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING: return c.getString(R.string.status_not_charging);
            default: return c.getString(R.string.status_unknown);
        }
    }

    public static String plugged(Context c, int plugged) {
        switch (plugged) {
            case BatteryManager.BATTERY_PLUGGED_AC: return c.getString(R.string.plug_ac);
            case BatteryManager.BATTERY_PLUGGED_USB: return c.getString(R.string.plug_usb);
            case BatteryManager.BATTERY_PLUGGED_WIRELESS: return c.getString(R.string.plug_wireless);
            case 8: return c.getString(R.string.plug_dock); // BATTERY_PLUGGED_DOCK (API 33+)
            default: return c.getString(R.string.plug_other);
        }
    }

    public static String health(Context c, int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return c.getString(R.string.health_good);
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return c.getString(R.string.health_overheat);
            case BatteryManager.BATTERY_HEALTH_DEAD: return c.getString(R.string.health_dead);
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return c.getString(R.string.health_over_voltage);
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: return c.getString(R.string.health_failure);
            case BatteryManager.BATTERY_HEALTH_COLD: return c.getString(R.string.health_cold);
            default: return c.getString(R.string.health_unknown);
        }
    }
}
