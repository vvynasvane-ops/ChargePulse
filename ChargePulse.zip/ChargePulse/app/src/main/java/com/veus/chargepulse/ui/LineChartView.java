package com.veus.chargepulse.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.veus.chargepulse.R;

import java.util.Locale;

/** Small dependency-free line chart for the current history. */
public class LineChartView extends View {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint zero = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path linePath = new Path();
    private final Path fillPath = new Path();
    private final float density;

    private float[] data = new float[0];
    private int color;

    public LineChartView(Context context) {
        this(context, null);
    }

    public LineChartView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public LineChartView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        density = getResources().getDisplayMetrics().density;
        color = ContextCompat.getColor(context, R.color.cp_cyan);

        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2f * density);
        line.setStrokeJoin(Paint.Join.ROUND);

        fill.setStyle(Paint.Style.FILL);

        grid.setColor(ContextCompat.getColor(context, R.color.cp_stroke));
        grid.setStrokeWidth(1f * density);

        zero.setColor(ContextCompat.getColor(context, R.color.cp_dim));
        zero.setStrokeWidth(1f * density);

        label.setColor(ContextCompat.getColor(context, R.color.cp_dim));
        label.setTextSize(10f * density);
    }

    public void setData(float[] values, int lineColor) {
        this.data = values == null ? new float[0] : values;
        this.color = lineColor;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float padL = 46f * density;
        float padR = 6f * density;
        float padT = 6f * density;
        float padB = 6f * density;
        float cw = w - padL - padR;
        float ch = h - padT - padB;
        if (cw <= 0 || ch <= 0) return;

        if (data.length < 2) {
            label.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(getContext().getString(R.string.chart_waiting), w / 2f, h / 2f, label);
            label.setTextAlign(Paint.Align.LEFT);
            return;
        }

        float min = data[0];
        float max = data[0];
        for (float v : data) {
            if (v < min) min = v;
            if (v > max) max = v;
        }
        min = Math.min(min, 0f);
        max = Math.max(max, 0f);
        if (max - min < 100f) {
            float mid = (max + min) / 2f;
            max = mid + 50f;
            min = mid - 50f;
        }
        float margin = (max - min) * 0.08f;
        max += margin;
        if (min < 0f) min -= margin;
        float range = max - min;

        for (int i = 0; i <= 3; i++) {
            float y = padT + ch * i / 3f;
            canvas.drawLine(padL, y, w - padR, y, grid);
            float value = max - range * i / 3f;
            canvas.drawText(String.format(Locale.US, "%.0f", value), 2f * density, y + 4f * density, label);
        }
        if (min < 0f && max > 0f) {
            float zy = padT + (max / range) * ch;
            canvas.drawLine(padL, zy, w - padR, zy, zero);
        }

        linePath.reset();
        fillPath.reset();
        float baseY = padT + ch;
        int n = data.length;
        for (int i = 0; i < n; i++) {
            float x = padL + cw * i / (n - 1f);
            float y = padT + (max - data[i]) / range * ch;
            if (i == 0) {
                linePath.moveTo(x, y);
                fillPath.moveTo(x, baseY);
                fillPath.lineTo(x, y);
            } else {
                linePath.lineTo(x, y);
                fillPath.lineTo(x, y);
            }
        }
        fillPath.lineTo(padL + cw, baseY);
        fillPath.close();

        fill.setColor((color & 0x00FFFFFF) | 0x26000000);
        line.setColor(color);
        canvas.drawPath(fillPath, fill);
        canvas.drawPath(linePath, line);
    }
}
