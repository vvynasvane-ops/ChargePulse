package com.veus.chargepulse.ui;

import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.veus.chargepulse.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Shows a system snapshot and the apps with the most screen time (proxy for battery cost). */
public class ConsumersFragment extends Fragment {
    private static final int MAX_APPS = 25;

    private static final class AppRow {
        final String name;
        final long ms;
        AppRow(String name, long ms) {
            this.name = name;
            this.ms = ms;
        }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView tvSystem, tvAppsNote;
    private View cardGrant;
    private LinearLayout llApps;
    private volatile boolean loading;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_consumers, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        tvSystem = v.findViewById(R.id.tvSystem);
        tvAppsNote = v.findViewById(R.id.tvAppsNote);
        cardGrant = v.findViewById(R.id.cardGrant);
        llApps = v.findViewById(R.id.llApps);

        v.findViewById(R.id.btnGrantUsage).setOnClickListener(b ->
                open(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        v.findViewById(R.id.btnDisplay).setOnClickListener(b ->
                open(Settings.ACTION_DISPLAY_SETTINGS));
        v.findViewById(R.id.btnSaver).setOnClickListener(b ->
                open(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        v.findViewById(R.id.btnOptimize).setOnClickListener(b ->
                open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshSystem();
        refreshApps();
    }

    private void open(String action) {
        try {
            startActivity(new Intent(action));
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(requireContext(), R.string.settings_unavailable, Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshSystem() {
        Context c = requireContext();
        String brightness;
        try {
            int raw = Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            brightness = Math.round(raw * 100f / 255f) + "%";
        } catch (Settings.SettingNotFoundException e) {
            brightness = getString(R.string.unknown);
        }
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        String saver = pm == null ? getString(R.string.unknown)
                : getString(pm.isPowerSaveMode() ? R.string.on : R.string.off);
        tvSystem.setText(getString(R.string.power_system, brightness, saver));
    }

    @SuppressWarnings("deprecation")
    private boolean hasUsageAccess(Context c) {
        AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        if (ops == null) return false;
        int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(), c.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private void refreshApps() {
        final Context app = requireContext().getApplicationContext();
        boolean ok = hasUsageAccess(app);
        cardGrant.setVisibility(ok ? View.GONE : View.VISIBLE);
        tvAppsNote.setVisibility(ok ? View.VISIBLE : View.GONE);
        llApps.removeAllViews();
        if (!ok || loading) return;

        loading = true;
        new Thread(() -> {
            final List<AppRow> rows = loadRows(app);
            handler.post(() -> {
                loading = false;
                if (!isAdded() || getView() == null) return;
                showRows(rows);
            });
        }, "usage-loader").start();
    }

    private List<AppRow> loadRows(Context app) {
        List<AppRow> rows = new ArrayList<>();
        try {
            UsageStatsManager usm = (UsageStatsManager) app.getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return rows;
            long end = System.currentTimeMillis();
            long start = end - 24L * 60L * 60L * 1000L;
            Map<String, UsageStats> map = usm.queryAndAggregateUsageStats(start, end);
            if (map == null) return rows;
            PackageManager pmgr = app.getPackageManager();
            for (Map.Entry<String, UsageStats> e : map.entrySet()) {
                long t = e.getValue().getTotalTimeInForeground();
                if (t < 30_000L) continue;
                String label;
                try {
                    label = String.valueOf(pmgr.getApplicationLabel(pmgr.getApplicationInfo(e.getKey(), 0)));
                } catch (PackageManager.NameNotFoundException ex) {
                    label = e.getKey();
                }
                rows.add(new AppRow(label, t));
            }
            Collections.sort(rows, new Comparator<AppRow>() {
                @Override
                public int compare(AppRow a, AppRow b) {
                    return Long.compare(b.ms, a.ms);
                }
            });
            if (rows.size() > MAX_APPS) rows = new ArrayList<>(rows.subList(0, MAX_APPS));
        } catch (RuntimeException ignored) {
            // usage stats can throw on some OEM builds; show whatever we have
        }
        return rows;
    }

    private void showRows(List<AppRow> rows) {
        llApps.removeAllViews();
        if (rows.isEmpty()) {
            TextView empty = new TextView(requireContext());
            empty.setText(R.string.apps_none);
            empty.setTextColor(requireContext().getColor(R.color.cp_dim));
            llApps.addView(empty);
            return;
        }
        long top = rows.get(0).ms;
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        for (AppRow r : rows) {
            View item = inflater.inflate(R.layout.item_app, llApps, false);
            ((TextView) item.findViewById(R.id.tvAppName)).setText(r.name);
            ((TextView) item.findViewById(R.id.tvAppTime)).setText(formatTime(r.ms));
            ((ProgressBar) item.findViewById(R.id.bar)).setProgress((int) (r.ms * 100L / top));
            llApps.addView(item);
        }
    }

    private String formatTime(long ms) {
        long minutes = ms / 60000L;
        if (minutes < 60) return getString(R.string.time_min, (int) Math.max(minutes, 1));
        return getString(R.string.time_h_min, (int) (minutes / 60), (int) (minutes % 60));
    }
}
