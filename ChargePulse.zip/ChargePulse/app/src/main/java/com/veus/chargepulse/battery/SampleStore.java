package com.veus.chargepulse.battery;

import java.util.ArrayDeque;
import java.util.Iterator;

/** Process-wide ring buffer of recent samples, shared by the service and the Live screen. */
public final class SampleStore {
    private static final int MAX = 300;
    private static final ArrayDeque<BatterySample> BUF = new ArrayDeque<>();
    private static boolean init;
    private static boolean lastPlugged;
    private static double sum;
    private static int count;
    private static float peak;
    private static int zeroStreak;

    private SampleStore() { }

    public static synchronized void add(BatterySample s) {
        if (init && s.isPlugged() != lastPlugged) {
            resetStats();
        }
        init = true;
        lastPlugged = s.isPlugged();

        BUF.addLast(s);
        if (BUF.size() > MAX) BUF.removeFirst();

        if (s.currentSupported) {
            sum += s.currentMa;
            count++;
            peak = Math.max(peak, Math.abs(s.currentMa));
            zeroStreak = (s.currentMa == 0f) ? zeroStreak + 1 : 0;
        }
    }

    public static synchronized void resetStats() {
        BUF.clear();
        sum = 0;
        count = 0;
        peak = 0;
        zeroStreak = 0;
    }

    public static synchronized BatterySample latest() {
        return BUF.peekLast();
    }

    public static synchronized float[] currents() {
        float[] out = new float[BUF.size()];
        int k = 0;
        for (BatterySample s : BUF) out[k++] = s.currentMa;
        return out;
    }

    public static synchronized float peakMa() { return peak; }

    public static synchronized float avgMa() { return count > 0 ? (float) (sum / count) : 0f; }

    public static synchronized int zeroCurrentStreak() { return zeroStreak; }

    private static float recentAvg(int n) {
        double total = 0;
        int taken = 0;
        Iterator<BatterySample> it = BUF.descendingIterator();
        while (it.hasNext() && taken < n) {
            BatterySample s = it.next();
            if (!s.currentSupported) continue;
            total += s.currentMa;
            taken++;
        }
        return taken > 0 ? (float) (total / taken) : 0f;
    }

    /**
     * Rough hours to full (plugged) or to empty (unplugged), or -1 when unknown.
     * Full capacity is estimated from the charge counter and the battery percentage.
     */
    public static synchronized float etaHours() {
        BatterySample s = BUF.peekLast();
        if (s == null || s.chargeUah <= 0 || s.level <= 0) return -1f;
        float avg = recentAvg(30);
        float nowMah = s.chargeUah / 1000f;
        float fullMah = nowMah * 100f / s.level;
        float hours = -1f;
        if (s.isPlugged() && avg > 50f) {
            float remaining = fullMah - nowMah;
            if (remaining > 0f) hours = remaining / avg;
        } else if (!s.isPlugged() && avg < -20f) {
            hours = nowMah / (-avg);
        }
        return hours > 72f ? -1f : hours;
    }
}
