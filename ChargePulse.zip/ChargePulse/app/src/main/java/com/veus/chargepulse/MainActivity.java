package com.veus.chargepulse;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.veus.chargepulse.data.Prefs;
import com.veus.chargepulse.ui.ConsumersFragment;
import com.veus.chargepulse.ui.HistoryFragment;
import com.veus.chargepulse.ui.LiveFragment;
import com.veus.chargepulse.ui.SettingsFragment;
import com.veus.chargepulse.ui.TesterFragment;

public class MainActivity extends AppCompatActivity {

    private final ActivityResultLauncher<String> notificationPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.nav);
        nav.setOnItemSelectedListener(item -> {
            show(item.getItemId());
            return true;
        });
        nav.setOnItemReselectedListener(item -> { });

        if (savedInstanceState == null) {
            nav.setSelectedItemId(R.id.nav_live);
        }
        askNotificationPermissionOnce();
    }

    private void show(int id) {
        Fragment f;
        if (id == R.id.nav_test) {
            f = new TesterFragment();
        } else if (id == R.id.nav_history) {
            f = new HistoryFragment();
        } else if (id == R.id.nav_power) {
            f = new ConsumersFragment();
        } else if (id == R.id.nav_settings) {
            f = new SettingsFragment();
        } else {
            f = new LiveFragment();
        }
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, f)
                .commit();
    }

    private void askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33) return;
        Prefs prefs = new Prefs(this);
        if (prefs.notifAsked()) return;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            prefs.setNotifAsked(true);
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }
}
