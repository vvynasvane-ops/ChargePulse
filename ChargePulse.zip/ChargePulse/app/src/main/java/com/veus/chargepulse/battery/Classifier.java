package com.veus.chargepulse.battery;

import com.veus.chargepulse.R;

/** Maps an average charging current to a plain-language rating. Bands are generic phone values. */
public final class Classifier {
    public static final int VERY_SLOW = 0, SLOW = 1, NORMAL = 2, FAST = 3, VERY_FAST = 4;

    private Classifier() { }

    public static int rate(float avgMa) {
        if (avgMa < 500f) return VERY_SLOW;
        if (avgMa < 1000f) return SLOW;
        if (avgMa < 2000f) return NORMAL;
        if (avgMa < 3500f) return FAST;
        return VERY_FAST;
    }

    public static int labelRes(int rating) {
        switch (rating) {
            case VERY_SLOW: return R.string.rate_very_slow;
            case SLOW: return R.string.rate_slow;
            case NORMAL: return R.string.rate_normal;
            case FAST: return R.string.rate_fast;
            default: return R.string.rate_very_fast;
        }
    }

    public static int colorRes(int rating) {
        switch (rating) {
            case VERY_SLOW: return R.color.cp_red;
            case SLOW: return R.color.cp_amber;
            default: return R.color.cp_green;
        }
    }
}
