package com.veus.chargepulse.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.veus.chargepulse.R;
import com.veus.chargepulse.data.Session;
import com.veus.chargepulse.data.SessionDb;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryFragment extends Fragment {
    private final List<Session> items = new ArrayList<>();
    private SessionAdapter adapter;
    private ListView list;
    private TextView tvEmpty;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        list = v.findViewById(R.id.lvHistory);
        tvEmpty = v.findViewById(R.id.tvEmpty);
        adapter = new SessionAdapter();
        list.setAdapter(adapter);

        list.setOnItemLongClickListener((parent, view, position, id) -> {
            final Session s = items.get(position);
            new MaterialAlertDialogBuilder(requireContext())
                    .setTitle(R.string.delete_title)
                    .setNegativeButton(R.string.cancel, null)
                    .setPositiveButton(R.string.delete, (d, w) -> {
                        SessionDb.get(requireContext()).delete(s.id);
                        reload();
                    })
                    .show();
            return true;
        });

        v.findViewById(R.id.btnShare).setOnClickListener(b -> shareCsv());
        v.findViewById(R.id.btnClear).setOnClickListener(b ->
                new MaterialAlertDialogBuilder(requireContext())
                        .setTitle(R.string.clear_title)
                        .setNegativeButton(R.string.cancel, null)
                        .setPositiveButton(R.string.delete, (d, w) -> {
                            SessionDb.get(requireContext()).clear();
                            reload();
                        })
                        .show());
    }

    @Override
    public void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        if (!isAdded() || getView() == null) return;
        items.clear();
        try {
            items.addAll(SessionDb.get(requireContext()).list(200));
        } catch (RuntimeException ignored) {
            // show an empty list rather than crash
        }
        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        list.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void shareCsv() {
        StringBuilder sb = new StringBuilder(
                "type,label,start,duration_min,start_level,end_level,avg_ma,peak_ma,avg_w,avg_temp_c,max_temp_c\n");
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        for (Session s : items) {
            sb.append(typeName(s.type)).append(',')
                    .append('"').append(s.label.replace("\"", "\"\"")).append('"').append(',')
                    .append(iso.format(new Date(s.startMs))).append(',')
                    .append(String.format(Locale.US, "%.1f", (s.endMs - s.startMs) / 60000f)).append(',')
                    .append(s.startLevel).append(',')
                    .append(s.endLevel).append(',')
                    .append(String.format(Locale.US, "%.0f", s.avgMa)).append(',')
                    .append(String.format(Locale.US, "%.0f", s.peakMa)).append(',')
                    .append(String.format(Locale.US, "%.2f", s.avgPowerW)).append(',')
                    .append(String.format(Locale.US, "%.1f", s.avgTempC)).append(',')
                    .append(String.format(Locale.US, "%.1f", s.maxTempC)).append('\n');
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.share_title));
        send.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(send, getString(R.string.share_title)));
    }

    private static String typeName(int type) {
        switch (type) {
            case Session.CHARGE: return "charge";
            case Session.TEST: return "test";
            default: return "drain";
        }
    }

    private final class SessionAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int position) { return items.get(position); }
        @Override public long getItemId(int position) { return items.get(position).id; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_session, parent, false);
            }
            Context c = parent.getContext();
            Session s = items.get(position);

            TextView tvType = v.findViewById(R.id.tvType);
            TextView tvTitle = v.findViewById(R.id.tvTitle);
            TextView tvWhen = v.findViewById(R.id.tvWhen);
            TextView tvStats = v.findViewById(R.id.tvStats);
            TextView tvLevels = v.findViewById(R.id.tvLevels);

            int typeRes;
            int colorRes;
            if (s.type == Session.CHARGE) {
                typeRes = R.string.type_charge;
                colorRes = R.color.cp_green;
            } else if (s.type == Session.TEST) {
                typeRes = R.string.type_test;
                colorRes = R.color.cp_amber;
            } else {
                typeRes = R.string.type_discharge;
                colorRes = R.color.cp_cyan;
            }
            tvType.setText(typeRes);
            tvType.setTextColor(ContextCompat.getColor(c, colorRes));
            tvTitle.setText(s.label == null || s.label.isEmpty() ? "\u2014" : s.label);
            tvWhen.setText(c.getString(R.string.session_when,
                    dateFormat.format(new Date(s.startMs)), Fmt.duration(s.endMs - s.startMs)));
            tvStats.setText(c.getString(R.string.session_stats,
                    Fmt.ma(s.avgMa), Fmt.maAbs(s.peakMa), s.avgPowerW));
            tvLevels.setText(c.getString(R.string.session_levels,
                    s.startLevel, s.endLevel, Fmt.temp(s.maxTempC)));
            return v;
        }
    }
}
