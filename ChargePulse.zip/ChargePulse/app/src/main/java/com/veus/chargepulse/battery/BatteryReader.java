package com.veus.chargepulse.battery;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.SystemClock;

import com.veus.chargepulse.R;
import com.veus.chargepulse.data.Prefs;

/** Reads the battery and normalises unit and sign quirks between devices. */
public final class BatteryReader {
    private final Context app;
    private final BatteryManager bm;
    private final Prefs prefs;

    public BatteryReader(Context context) {
        this.app = context.getApplicationContext();
        this.bm = (BatteryManager) app.getSystemService(Context.BATTERY_SERVICE);
        this.prefs = new Prefs(app);
    }

    public BatterySample read() {
        Intent i = app.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        int level = -1;
        int status = BatteryManager.BATTERY_STATUS_UNKNOWN;
        int plugged = 0;
        int health = BatteryManager.BATTERY_HEALTH_UNKNOWN;
        int cycles = -1;
        int mv = 0;
        float tempC = 0f;

        if (i != null) {
            int lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            level = (lv >= 0 && scale > 0) ? Math.round(lv * 100f / scale) : -1;
            status = i.getIntExtra(BatteryManager.EXTRA_STATUS, status);
            plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            health = i.getIntExtra(BatteryManager.EXTRA_HEALTH, health);
            tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
            if (mv > 0 && mv < 100) mv = mv * 1000; // a few devices report volts
            if (Build.VERSION.SDK_INT >= 34) {
                cycles = i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1);
            }
        }

        long raw = rawCurrent();
        boolean supported = raw != Long.MIN_VALUE && raw != Integer.MIN_VALUE;
        float ma = 0f;
        if (supported) {
            ma = applySign(toMa(raw, plugged != 0), status);
        }

        long chargeUah = -1;
        try {
            long cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            if (cc > 0 && cc != Long.MIN_VALUE && cc != Integer.MIN_VALUE) chargeUah = cc;
        } catch (Throwable ignored) {
            // property not available on this device
        }

        return new BatterySample(System.currentTimeMillis(), ma, supported ? raw : 0L, mv, tempC,
                level, status, plugged, health, cycles, chargeUah, supported);
    }

    private long rawCurrent() {
        try {
            return bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
        } catch (Throwable t) {
            return Long.MIN_VALUE;
        }
    }

    /**
     * The Android spec says microamps, but some older Samsung/MTK devices return milliamps.
     * In auto mode we keep the largest magnitude ever seen. A phone that is plugged in but never
     * reported more than 12000 "units" is almost certainly reporting milliamps.
     */
    private float toMa(long raw, boolean plugged) {
        int mode = prefs.unitMode();
        if (mode == Prefs.UNIT_UA) return raw / 1000f;
        if (mode == Prefs.UNIT_MA) return raw;

        long abs = Math.abs(raw);
        long max = prefs.rawMax();
        if (abs > max) {
            max = abs;
            prefs.setRawMax(max);
        }
        boolean looksLikeMa = plugged && max > 0 && max < 12000;
        return looksLikeMa ? raw : raw / 1000f;
    }

    private float applySign(float ma, int status) {
        int mode = prefs.signMode();
        if (mode == Prefs.SIGN_INVERT) return -ma;
        if (mode == Prefs.SIGN_NORMAL) return ma;
        if (status == BatteryManager.BATTERY_STATUS_CHARGING) return Math.abs(ma);
        if (status == BatteryManager.BATTERY_STATUS_DISCHARGING) return -Math.abs(ma);
        return ma;
    }

    public String diagnostics() {
        long raw = rawCurrent();
        boolean supported = raw != Long.MIN_VALUE && raw != Integer.MIN_VALUE;
        BatterySample s = read();
        String unit;
        switch (prefs.unitMode()) {
            case Prefs.UNIT_UA: unit = app.getString(R.string.diag_unit_ua); break;
            case Prefs.UNIT_MA: unit = app.getString(R.string.diag_unit_ma); break;
            default: unit = app.getString(R.string.diag_unit_auto); break;
        }
        String rawText = supported ? String.valueOf(raw) : app.getString(R.string.diag_unsupported);
        String interpreted = supported
                ? String.format(java.util.Locale.US, "%+,.1f mA", s.currentMa)
                : app.getString(R.string.not_available);
        String counter = s.chargeUah > 0
                ? String.format(java.util.Locale.US, "%,.0f mAh", s.chargeUah / 1000f)
                : app.getString(R.string.not_available);
        return app.getString(R.string.diag_text, rawText, interpreted, unit, counter, Build.VERSION.SDK_INT);
    }

    /** Monotonic helper for callers that need elapsed time. */
    public static long elapsedMs() {
        return SystemClock.elapsedRealtime();
    }
}
