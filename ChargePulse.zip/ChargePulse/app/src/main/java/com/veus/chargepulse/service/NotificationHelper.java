package com.veus.chargepulse.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.veus.chargepulse.MainActivity;
import com.veus.chargepulse.R;

public final class NotificationHelper {
    public static final String CH_MONITOR = "monitor";
    public static final String CH_ALERTS = "alerts";
    public static final int ID_MONITOR = 1001;

    private NotificationHelper() { }

    public static void createChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        NotificationChannel monitor = new NotificationChannel(
                CH_MONITOR, c.getString(R.string.ch_monitor), NotificationManager.IMPORTANCE_LOW);
        monitor.setShowBadge(false);
        nm.createNotificationChannel(monitor);

        NotificationChannel alerts = new NotificationChannel(
                CH_ALERTS, c.getString(R.string.ch_alerts), NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(alerts);
    }

    private static PendingIntent openApp(Context c) {
        Intent open = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static Notification monitor(Context c, String text) {
        Intent stop = new Intent(c, MonitorService.class).setAction(MonitorService.ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(c, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(c, CH_MONITOR)
                .setSmallIcon(R.drawable.ic_stat_bolt)
                .setContentTitle(c.getString(R.string.notif_title))
                .setContentText(text)
                .setColor(ContextCompat.getColor(c, R.color.cp_cyan))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .setContentIntent(openApp(c))
                .addAction(0, c.getString(R.string.notif_stop), stopPi)
                .build();
    }

    public static void updateMonitor(Context c, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(ID_MONITOR, monitor(c, text));
    }

    public static void alert(Context c, int id, String title, String text) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                c, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification n = new NotificationCompat.Builder(c, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat_bolt)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setColor(ContextCompat.getColor(c, R.color.cp_amber))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .setContentIntent(openApp(c))
                .build();
        nm.notify(id, n);
    }
}
