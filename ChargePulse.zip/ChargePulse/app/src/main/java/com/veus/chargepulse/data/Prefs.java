package com.veus.chargepulse.data;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    public static final int UNIT_AUTO = 0, UNIT_UA = 1, UNIT_MA = 2;
    public static final int SIGN_AUTO = 0, SIGN_NORMAL = 1, SIGN_INVERT = 2;

    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("chargepulse_prefs", Context.MODE_PRIVATE);
    }

    public int unitMode() { return sp.getInt("unit_mode", UNIT_AUTO); }
    public void setUnitMode(int v) { sp.edit().putInt("unit_mode", v).apply(); }

    public int signMode() { return sp.getInt("sign_mode", SIGN_AUTO); }
    public void setSignMode(int v) { sp.edit().putInt("sign_mode", v).apply(); }

    public int intervalSec() { return sp.getInt("interval_sec", 2); }
    public void setIntervalSec(int v) { sp.edit().putInt("interval_sec", v).apply(); }

    public boolean alertsEnabled() { return sp.getBoolean("alerts", true); }
    public void setAlertsEnabled(boolean v) { sp.edit().putBoolean("alerts", v).apply(); }

    public int slowMa() { return sp.getInt("slow_ma", 1000); }
    public int slowSec() { return sp.getInt("slow_sec", 60); }
    public int drainMa() { return sp.getInt("drain_ma", 400); }
    public int drainSec() { return sp.getInt("drain_sec", 30); }
    public int tempLimitC() { return sp.getInt("temp_c", 42); }

    public void setThresholds(int slowMa, int slowSec, int drainMa, int drainSec, int tempC) {
        sp.edit()
                .putInt("slow_ma", slowMa)
                .putInt("slow_sec", slowSec)
                .putInt("drain_ma", drainMa)
                .putInt("drain_sec", drainSec)
                .putInt("temp_c", tempC)
                .apply();
    }

    /** Largest absolute raw CURRENT_NOW value ever seen; used by unit auto-detection. */
    public long rawMax() { return sp.getLong("raw_max", 0L); }
    public void setRawMax(long v) { sp.edit().putLong("raw_max", v).apply(); }

    public boolean notifAsked() { return sp.getBoolean("notif_asked", false); }
    public void setNotifAsked(boolean v) { sp.edit().putBoolean("notif_asked", v).apply(); }
}
