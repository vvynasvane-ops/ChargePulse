package com.veus.chargepulse.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.ArrayRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.materialswitch.MaterialSwitch;
import com.veus.chargepulse.R;
import com.veus.chargepulse.battery.BatteryReader;
import com.veus.chargepulse.data.Prefs;

public class SettingsFragment extends Fragment {
    private static final int[] INTERVALS_S = {1, 2, 3, 5};

    private Prefs prefs;
    private BatteryReader reader;
    private Spinner spUnit, spSign, spInterval;
    private MaterialSwitch swAlerts;
    private EditText etSlowMa, etSlowSec, etDrainMa, etDrainSec, etTemp;
    private TextView tvDiag;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        Context c = requireContext();
        prefs = new Prefs(c);
        reader = new BatteryReader(c);

        spUnit = v.findViewById(R.id.spUnit);
        spSign = v.findViewById(R.id.spSign);
        spInterval = v.findViewById(R.id.spInterval);
        swAlerts = v.findViewById(R.id.swAlerts);
        etSlowMa = v.findViewById(R.id.etSlowMa);
        etSlowSec = v.findViewById(R.id.etSlowSec);
        etDrainMa = v.findViewById(R.id.etDrainMa);
        etDrainSec = v.findViewById(R.id.etDrainSec);
        etTemp = v.findViewById(R.id.etTemp);
        tvDiag = v.findViewById(R.id.tvDiag);

        fill(spUnit, R.array.unit_modes);
        fill(spSign, R.array.sign_modes);
        fill(spInterval, R.array.intervals);

        spUnit.setSelection(prefs.unitMode());
        spSign.setSelection(prefs.signMode());
        spInterval.setSelection(indexOf(INTERVALS_S, prefs.intervalSec()));
        swAlerts.setChecked(prefs.alertsEnabled());
        etSlowMa.setText(String.valueOf(prefs.slowMa()));
        etSlowSec.setText(String.valueOf(prefs.slowSec()));
        etDrainMa.setText(String.valueOf(prefs.drainMa()));
        etDrainSec.setText(String.valueOf(prefs.drainSec()));
        etTemp.setText(String.valueOf(prefs.tempLimitC()));

        v.findViewById(R.id.btnSave).setOnClickListener(b -> save());
        v.findViewById(R.id.btnResetUnit).setOnClickListener(b -> {
            prefs.setRawMax(0L);
            refreshDiag();
        });
        v.findViewById(R.id.btnRefreshDiag).setOnClickListener(b -> refreshDiag());
        refreshDiag();
    }

    private void fill(Spinner sp, @ArrayRes int array) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                requireContext(), array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adapter);
    }

    private static int indexOf(int[] values, int value) {
        for (int i = 0; i < values.length; i++) {
            if (values[i] == value) return i;
        }
        return 1;
    }

    private static int parse(EditText et, int fallback, int min, int max) {
        try {
            int v = Integer.parseInt(et.getText().toString().trim());
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private void save() {
        prefs.setUnitMode(spUnit.getSelectedItemPosition());
        prefs.setSignMode(spSign.getSelectedItemPosition());
        int pos = Math.max(0, Math.min(spInterval.getSelectedItemPosition(), INTERVALS_S.length - 1));
        prefs.setIntervalSec(INTERVALS_S[pos]);
        prefs.setAlertsEnabled(swAlerts.isChecked());
        prefs.setThresholds(
                parse(etSlowMa, 1000, 50, 20000),
                parse(etSlowSec, 60, 5, 3600),
                parse(etDrainMa, 400, 50, 20000),
                parse(etDrainSec, 30, 5, 3600),
                parse(etTemp, 42, 30, 80));
        Toast.makeText(requireContext(), R.string.settings_saved, Toast.LENGTH_SHORT).show();
        refreshDiag();
    }

    private void refreshDiag() {
        if (tvDiag != null && reader != null) tvDiag.setText(reader.diagnostics());
    }
}
