package com.veus.chargepulse;

import android.app.Application;

import com.veus.chargepulse.service.NotificationHelper;

public class ChargePulseApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        NotificationHelper.createChannels(this);
    }
}
