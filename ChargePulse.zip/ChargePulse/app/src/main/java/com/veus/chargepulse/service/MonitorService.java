package com.veus.chargepulse.service;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import androidx.core.app.ServiceCompat;

import com.veus.chargepulse.R;
import com.veus.chargepulse.battery.BatteryReader;
import com.veus.chargepulse.battery.BatterySample;
import com.veus.chargepulse.battery.SampleStore;
import com.veus.chargepulse.data.Prefs;
import com.veus.chargepulse.ui.Fmt;

/** Foreground service that keeps sampling with the screen off, logs sessions and raises alerts. */
public class MonitorService extends Service {
    public static final String ACTION_STOP = "com.veus.chargepulse.action.STOP";

    private static final int ALERT_SLOW = 2001;
    private static final int ALERT_DRAIN = 2002;
    private static final int ALERT_TEMP = 2003;
    private static final long COOLDOWN_MS = 5 * 60 * 1000L;
    private static final long NOTIFICATION_EVERY_MS = 3000L;
    private static final long IDLE_INTERVAL_MS = 10_000L;

    private static volatile boolean running;

    public static boolean isRunning() {
        return running;
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BatteryReader reader;
    private Prefs prefs;
    private PowerManager pm;
    private SessionTracker tracker;
    private boolean started;

    private long slowSince;
    private long drainSince;
    private long lastSlowAlert;
    private long lastDrainAlert;
    private long lastTempAlert;
    private long lastNotification;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                BatterySample s = reader.read();
                SampleStore.add(s);
                tracker.onSample(s);
                checkAlerts(s);
                updateNotification(s);
                handler.postDelayed(this, nextDelay(s));
            } catch (RuntimeException e) {
                // keep the loop alive after a transient failure
                handler.postDelayed(this, 5000L);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        reader = new BatteryReader(this);
        prefs = new Prefs(this);
        pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        tracker = new SessionTracker(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!started) {
            started = true;
            if (!enterForeground()) {
                stopSelf();
                return START_NOT_STICKY;
            }
            running = true;
            handler.post(tick);
        }
        return START_NOT_STICKY;
    }

    private boolean enterForeground() {
        Notification n = NotificationHelper.monitor(this, getString(R.string.notif_starting));
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, NotificationHelper.ID_MONITOR, n,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NotificationHelper.ID_MONITOR, n);
            }
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Sample fast while the screen is on or charging, and slowly while idle to save power. */
    private long nextDelay(BatterySample s) {
        long base = prefs.intervalSec() * 1000L;
        boolean screenOn = pm != null && pm.isInteractive();
        if (!screenOn && !s.isPlugged()) return Math.max(base, IDLE_INTERVAL_MS);
        return base;
    }

    private void updateNotification(BatterySample s) {
        if (s.timeMs - lastNotification < NOTIFICATION_EVERY_MS) return;
        lastNotification = s.timeMs;
        String text;
        if (s.currentSupported) {
            text = Fmt.ma(s.currentMa) + " \u00B7 " + Fmt.watts(s.powerW()) + " \u00B7 "
                    + Fmt.temp(s.tempC) + " \u00B7 " + s.level + "%";
        } else {
            text = Fmt.temp(s.tempC) + " \u00B7 " + s.level + "%";
        }
        NotificationHelper.updateMonitor(this, text);
    }

    private void checkAlerts(BatterySample s) {
        if (!prefs.alertsEnabled()) return;
        long now = s.timeMs;

        if (s.currentSupported && s.currentMa != 0f) {
            // Slow charging
            if (s.isCharging() && s.level < 95 && s.currentMa < prefs.slowMa()) {
                if (slowSince == 0) slowSince = now;
                if (now - slowSince >= prefs.slowSec() * 1000L && now - lastSlowAlert > COOLDOWN_MS) {
                    lastSlowAlert = now;
                    NotificationHelper.alert(this, ALERT_SLOW, getString(R.string.alert_slow_title),
                            getString(R.string.alert_slow_text, Fmt.ma(s.currentMa)));
                }
            } else {
                slowSince = 0;
            }

            // Unusual drain while idle
            boolean idle = pm != null && !pm.isInteractive();
            if (!s.isPlugged() && idle && -s.currentMa > prefs.drainMa()) {
                if (drainSince == 0) drainSince = now;
                if (now - drainSince >= prefs.drainSec() * 1000L && now - lastDrainAlert > COOLDOWN_MS) {
                    lastDrainAlert = now;
                    NotificationHelper.alert(this, ALERT_DRAIN, getString(R.string.alert_drain_title),
                            getString(R.string.alert_drain_text, Fmt.maAbs(s.currentMa)));
                }
            } else {
                drainSince = 0;
            }
        }

        // Temperature
        if (s.tempC >= prefs.tempLimitC() && now - lastTempAlert > COOLDOWN_MS) {
            lastTempAlert = now;
            NotificationHelper.alert(this, ALERT_TEMP, getString(R.string.alert_temp_title),
                    getString(R.string.alert_temp_text, Fmt.temp(s.tempC)));
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (tracker != null) tracker.finish();
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
