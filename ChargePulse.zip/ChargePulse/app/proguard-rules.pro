# ChargePulse uses no reflection or third-party serialisation, so no custom rules are needed.
-keep class com.veus.chargepulse.service.MonitorService { *; }
