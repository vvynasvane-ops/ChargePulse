@echo off
setlocal
cd /d "%~dp0"

if not exist gradle\wrapper mkdir gradle\wrapper

if not exist gradle\wrapper\gradle-wrapper.jar (
  echo Downloading gradle-wrapper.jar 8.10.2 ...
  curl -L -o gradle\wrapper\gradle-wrapper.jar https://github.com/gradle/gradle/raw/v8.10.2/gradle/wrapper/gradle-wrapper.jar
)

if not exist local.properties (
  echo sdk.dir=C\:\\Users\\Lenovo\\AppData\\Local\\Android\\Sdk> local.properties
)

echo Setup complete.
endlocal
