# ChargePulse

Battery current / charger tester for Android. Pure Java + XML (no Kotlin, no Compose, no Room, no kapt).
Only three libraries: AppCompat, Core, Material.

## Build (Windows CMD)

    clean_build.bat        (clean + assembleDebug)
    build.bat              (assembleDebug)

Manual equivalent:

    gradlew.bat clean
    gradlew.bat clean assembleDebug
    gradlew.bat assembleDebug

APK: app\build\outputs\apk\debug\app-debug.apk

`setup.bat` (called automatically) downloads gradle-wrapper.jar 8.10.2 if it is missing and writes
local.properties if it is missing. Edit local.properties if your SDK is somewhere else.

## Toolchain

- Gradle 8.10.2 (first Gradle line that runs on JDK 23)
- Android Gradle Plugin 8.7.3
- compileSdk / targetSdk 34, minSdk 24, Java 17 source level

## Screens

- Live: current (mA), power (W), voltage, temperature, level, time estimate, rolling chart, peak/average, health, background monitor toggle
- Tester: timed charger/cable test with verdict, label and auto-save, best-so-far
- History: charge / drain / test sessions, CSV share, long-press to delete
- Power: system snapshot, top apps by 24 h screen time (needs Usage access), shortcuts to Android settings
- Settings: unit and sign override, sampling interval, alert thresholds, device diagnostics

## Known limits

- CURRENT_NOW accuracy depends on the phone's fuel gauge. Use Settings > Device diagnostics to check the raw value.
- Per-app battery drain is not exposed to normal apps, so screen time is used as a proxy.
- Foreground service type is specialUse. A Play Store release needs a declaration for it.
