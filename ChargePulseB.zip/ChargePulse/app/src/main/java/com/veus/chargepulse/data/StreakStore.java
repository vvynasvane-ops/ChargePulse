package com.veus.chargepulse.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.TimeZone;

/**
 * Daily "Pulse streak". A day counts when the user charges for 5+ minutes, runs a Tester test
 * or completes an AR scan. Every 7th streak day banks a freeze (max 2) that silently covers a
 * missed day. Points feed a level ladder (see R.array.streak_levels).
 */
public final class StreakStore {
    public static final int PTS_CHARGE = 10, PTS_TEST = 25, PTS_SCAN = 40;
    public static final int MAX_FREEZES = 2;
    private static final long DAY_MS = 86_400_000L;
    private static final int[] LEVEL_XP = {0, 50, 150, 300, 600, 1000, 2000};

    public static final class Snapshot {
        public int streak, best, freezes, totalDays, xp, level;
        /** XP earned inside the current level and the size of that level (0 at max level). */
        public int xpIntoLevel, xpForLevel;
        public boolean doneToday, atRisk;
        /** Oldest to today: 0 = nothing, 1 = pulse logged, 2 = saved by a freeze. */
        public final int[] week = new int[7];
    }

    private StreakStore() { }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("chargepulse_streak", Context.MODE_PRIVATE);
    }

    /** Local calendar day number. */
    private static long today() {
        long now = System.currentTimeMillis();
        return (now + TimeZone.getDefault().getOffset(now)) / DAY_MS;
    }

    private static boolean has(String csv, long day) {
        return ("," + csv + ",").contains("," + day + ",");
    }

    private static String push(String csv, long day) {
        String[] parts = csv.isEmpty() ? new String[0] : csv.split(",");
        StringBuilder sb = new StringBuilder();
        for (int i = Math.max(0, parts.length - 19); i < parts.length; i++) sb.append(parts[i]).append(',');
        return sb.append(day).toString();
    }

    /** Logs activity for today and returns the new state. Safe to call many times a day. */
    public static synchronized Snapshot record(Context c, int points) {
        SharedPreferences sp = sp(c);
        long today = today();
        long last = sp.getLong("last_day", 0L);
        int streak = sp.getInt("streak", 0);
        int freezes = sp.getInt("freezes", 0);
        int best = sp.getInt("best", 0);
        int total = sp.getInt("total_days", 0);
        int xp = sp.getInt("xp", 0) + Math.max(0, points);
        String recent = sp.getString("recent", "");
        String frozen = sp.getString("frozen", "");

        if (last < today) {
            if (last == 0L) {
                streak = 1;
            } else {
                long gap = today - last;
                if (gap == 1) {
                    streak++;
                } else {
                    long missed = gap - 1;
                    if (missed <= freezes) {
                        freezes -= (int) missed;
                        for (long d = last + 1; d < today; d++) frozen = push(frozen, d);
                        streak++;
                    } else {
                        streak = 1;
                    }
                }
            }
            recent = push(recent, today);
            total++;
            best = Math.max(best, streak);
            if (streak % 7 == 0 && freezes < MAX_FREEZES) freezes++;
            last = today;
        }

        sp.edit()
                .putLong("last_day", last).putInt("streak", streak).putInt("freezes", freezes)
                .putInt("best", best).putInt("total_days", total).putInt("xp", xp)
                .putString("recent", recent).putString("frozen", frozen)
                .apply();
        return snapshot(c);
    }

    public static synchronized Snapshot snapshot(Context c) {
        SharedPreferences sp = sp(c);
        long today = today();
        long last = sp.getLong("last_day", 0L);
        String recent = sp.getString("recent", "");
        String frozen = sp.getString("frozen", "");

        Snapshot s = new Snapshot();
        int streak = sp.getInt("streak", 0);
        s.freezes = sp.getInt("freezes", 0);
        s.best = Math.max(sp.getInt("best", 0), streak);
        s.totalDays = sp.getInt("total_days", 0);
        s.xp = sp.getInt("xp", 0);
        s.doneToday = last != 0L && last >= today;

        long gap = last == 0L ? 0L : today - last;
        if (last == 0L || (gap > 1 && gap - 1 > s.freezes)) streak = 0;
        s.streak = streak;
        s.atRisk = streak > 0 && !s.doneToday;

        for (int i = 0; i < 7; i++) {
            long day = today - 6 + i;
            s.week[i] = has(recent, day) ? 1 : has(frozen, day) ? 2 : 0;
        }

        int lvl = 0;
        for (int i = 0; i < LEVEL_XP.length; i++) if (s.xp >= LEVEL_XP[i]) lvl = i;
        s.level = lvl;
        s.xpIntoLevel = s.xp - LEVEL_XP[lvl];
        s.xpForLevel = lvl + 1 < LEVEL_XP.length ? LEVEL_XP[lvl + 1] - LEVEL_XP[lvl] : 0;
        return s;
    }
}
