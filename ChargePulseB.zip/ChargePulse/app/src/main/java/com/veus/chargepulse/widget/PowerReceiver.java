package com.veus.chargepulse.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Plug / unplug refreshes the widgets instantly, even when the monitor service is off. */
public class PowerReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        WidgetUpdater.updateAll(c);
    }
}
