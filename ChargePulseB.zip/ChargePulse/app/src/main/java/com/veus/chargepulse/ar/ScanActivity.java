package com.veus.chargepulse.ar;

import android.Manifest;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.material.button.MaterialButton;
import com.veus.chargepulse.MainActivity;
import com.veus.chargepulse.R;
import com.veus.chargepulse.battery.BatteryReader;
import com.veus.chargepulse.battery.BatterySample;
import com.veus.chargepulse.battery.Classifier;
import com.veus.chargepulse.data.Prefs;
import com.veus.chargepulse.data.Session;
import com.veus.chargepulse.data.SessionDb;
import com.veus.chargepulse.data.StreakStore;
import com.veus.chargepulse.ui.Fmt;
import com.veus.chargepulse.widget.WidgetUpdater;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * AR charger scanner: camera preview + pinned HUD. Aim at the charger / cable, tap SCAN and hold
 * steady for 10 s. The measurement is the same maths as the Tester tab; the result is saved to
 * History, feeds the streak, refreshes the widgets and can be shared as a snapshot.
 */
public class ScanActivity extends AppCompatActivity implements CameraController.Callback {
    private static final int WARMUP_S = 2, MEASURE_S = 8, TOTAL_S = WARMUP_S + MEASURE_S;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextureView texture;
    private ArOverlayView overlay;
    private TextView tvHint;
    private EditText etLabel;
    private MaterialButton btnScan, btnShare;
    private ImageButton btnTorch;

    private CameraController cam;
    private PoseTracker pose;
    private BatteryReader reader;
    private Prefs prefs;

    private int mode = ArOverlayView.IDLE;
    private boolean cameraOk, askedPermission, torchOn;
    private int elapsed, n, startLevel;
    private double sumMa, sumW;
    private float peakMa, startTemp, maxTemp;
    private long startMs;
    private String shareText = "";

    private final ActivityResultLauncher<String> camPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) startCamera(); else onError();
            });

    private final Runnable liveTick = new Runnable() {
        @Override
        public void run() {
            BatterySample s = reader.read();
            overlay.setLive(s, Fmt.stateColor(ScanActivity.this, s, prefs));
            if (mode == ArOverlayView.IDLE) {
                if (!s.isPlugged()) tvHint.setText(R.string.hint_plug);
                else tvHint.setText(cameraOk ? R.string.hint_aim : R.string.hint_aim_nocam);
            }
            handler.postDelayed(this, 500L);
        }
    };

    private final Runnable scanTick = new Runnable() {
        @Override
        public void run() {
            BatterySample s = reader.read();
            if (!s.isPlugged()) {
                abortScan(getString(R.string.test_unplugged));
                return;
            }
            elapsed++;
            overlay.setProgress(elapsed / (float) TOTAL_S);
            maxTemp = Math.max(maxTemp, s.tempC);
            if (elapsed > WARMUP_S) {
                sumMa += s.currentMa;
                sumW += s.powerW();
                n++;
                peakMa = Math.max(peakMa, Math.abs(s.currentMa));
            }
            tvHint.setText(getString(R.string.hint_hold, elapsed * 100 / TOTAL_S));
            if (elapsed >= TOTAL_S) finishScan(s);
            else handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_scan);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        texture = findViewById(R.id.texture);
        overlay = findViewById(R.id.overlay);
        tvHint = findViewById(R.id.tvHint);
        etLabel = findViewById(R.id.etScanLabel);
        btnScan = findViewById(R.id.btnScan);
        btnShare = findViewById(R.id.btnShare);
        btnTorch = findViewById(R.id.btnTorch);

        reader = new BatteryReader(this);
        prefs = new Prefs(this);
        pose = new PoseTracker(this);
        overlay.attachPose(pose);
        cam = new CameraController(this, texture, this);

        findViewById(R.id.btnBack).setOnClickListener(v -> leave());
        btnTorch.setOnClickListener(v -> {
            torchOn = cam.toggleTorch();
            btnTorch.setAlpha(torchOn ? 1f : 0.55f);
        });
        btnScan.setOnClickListener(v -> {
            if (mode == ArOverlayView.SCANNING) abortScan(null);
            else startScan();
        });
        btnShare.setOnClickListener(v -> share());

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                leave();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        pose.start();
        handler.post(liveTick);
        if (hasCameraPermission()) {
            startCamera();
        } else if (!askedPermission) {
            askedPermission = true;
            camPermission.launch(Manifest.permission.CAMERA);
        }
    }

    @Override
    protected void onPause() {
        handler.removeCallbacksAndMessages(null);
        if (mode == ArOverlayView.SCANNING) {
            mode = ArOverlayView.IDLE;
            overlay.setMode(ArOverlayView.IDLE);
        }
        cam.stop();
        cameraOk = false;
        pose.stop();
        super.onPause();
    }

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void startCamera() {
        cam.start();
    }

    private void leave() {
        if (isTaskRoot()) startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    // ---- camera callbacks (main thread) --------------------------------------------------

    @Override
    public void onState(boolean running, boolean flashAvailable) {
        if (isFinishing()) return;
        cameraOk = running;
        btnTorch.setVisibility(flashAvailable ? View.VISIBLE : View.GONE);
        btnTorch.setAlpha(torchOn ? 1f : 0.55f);
    }

    @Override
    public void onError() {
        if (isFinishing()) return;
        cameraOk = false;
        btnTorch.setVisibility(View.GONE);
        Toast.makeText(this, R.string.hint_no_cam, Toast.LENGTH_LONG).show();
    }

    // ---- scan flow -----------------------------------------------------------------------

    private void startScan() {
        BatterySample s = reader.read();
        if (!s.isPlugged()) {
            Toast.makeText(this, R.string.test_need_plug, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!s.currentSupported) {
            Toast.makeText(this, R.string.test_unsupported, Toast.LENGTH_LONG).show();
            return;
        }
        pose.recenter();
        elapsed = 0;
        sumMa = 0;
        sumW = 0;
        n = 0;
        peakMa = 0;
        startTemp = s.tempC;
        maxTemp = s.tempC;
        startLevel = s.level;
        startMs = System.currentTimeMillis();

        mode = ArOverlayView.SCANNING;
        overlay.setMode(ArOverlayView.SCANNING);
        btnScan.setText(R.string.btn_scan_cancel);
        btnShare.setVisibility(View.GONE);
        etLabel.setVisibility(View.GONE);
        tvHint.setText(getString(R.string.hint_hold, 0));
        overlay.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        handler.postDelayed(scanTick, 1000L);
    }

    private void abortScan(String message) {
        handler.removeCallbacks(scanTick);
        mode = ArOverlayView.IDLE;
        overlay.setMode(ArOverlayView.IDLE);
        btnScan.setText(R.string.btn_scan);
        etLabel.setVisibility(View.VISIBLE);
        if (message != null) Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void finishScan(BatterySample last) {
        handler.removeCallbacks(scanTick);
        if (n == 0) {
            abortScan(null);
            return;
        }
        float avgMa = (float) (sumMa / n);
        float avgW = (float) (sumW / n);
        int rating = Classifier.rate(avgMa);
        String verdict = getString(Classifier.shortRes(rating));
        int vColor = ContextCompat.getColor(this, Classifier.colorRes(rating));

        String label = etLabel.getText().toString().trim();
        if (label.isEmpty()) label = getString(R.string.scan_default_label);
        Session sess = new Session();
        sess.type = Session.TEST;
        sess.label = label;
        sess.startMs = startMs;
        sess.endMs = System.currentTimeMillis();
        sess.startLevel = startLevel;
        sess.endLevel = last.level;
        sess.avgMa = avgMa;
        sess.peakMa = peakMa;
        sess.avgPowerW = avgW;
        sess.avgTempC = (startTemp + maxTemp) / 2f;
        sess.maxTempC = maxTemp;
        try {
            SessionDb.get(this).insert(sess);
        } catch (RuntimeException ignored) {
            // result is still shown
        }

        boolean wasDone = StreakStore.snapshot(this).doneToday;
        StreakStore.Snapshot after = StreakStore.record(this, StreakStore.PTS_SCAN);
        WidgetUpdater.updateAll(this);

        mode = ArOverlayView.RESULT;
        overlay.setResult(avgMa, peakMa, avgW, maxTemp - startTemp, verdict, vColor,
                after.streak, StreakStore.PTS_SCAN, !wasDone);
        shareText = getString(R.string.share_text, label, verdict, Fmt.ma(avgMa));
        tvHint.setText(R.string.hint_result);
        btnScan.setText(R.string.btn_scan_again);
        btnShare.setVisibility(View.VISIBLE);
        etLabel.setVisibility(View.VISIBLE);
        overlay.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
    }

    // ---- share snapshot ------------------------------------------------------------------

    private void share() {
        int w = overlay.getWidth();
        int h = overlay.getHeight();
        if (w == 0 || h == 0) return;
        final Bitmap bmp;
        try {
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        } catch (RuntimeException | OutOfMemoryError e) {
            return;
        }
        Canvas cv = new Canvas(bmp);
        cv.drawColor(ContextCompat.getColor(this, R.color.cp_bg));
        if (cameraOk) {
            Bitmap frame = texture.getBitmap(w, h);
            if (frame != null) {
                cv.drawBitmap(frame, 0f, 0f, null);
                frame.recycle();
            }
        }
        overlay.draw(cv);
        final String text = shareText;

        new Thread(() -> {
            Uri uri = null;
            try {
                File dir = new File(getCacheDir(), "scans");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("cache dir");
                File f = new File(dir, "chargepulse_scan_" + System.currentTimeMillis() + ".jpg");
                try (FileOutputStream out = new FileOutputStream(f)) {
                    bmp.compress(Bitmap.CompressFormat.JPEG, 90, out);
                }
                uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            } catch (IOException | RuntimeException ignored) {
                // fall through; uri stays null
            }
            bmp.recycle();
            final Uri result = uri;
            runOnUiThread(() -> {
                if (isFinishing() || result == null) return;
                Intent send = new Intent(Intent.ACTION_SEND)
                        .setType("image/jpeg")
                        .putExtra(Intent.EXTRA_STREAM, result)
                        .putExtra(Intent.EXTRA_TEXT, text)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(ClipData.newRawUri("", result));
                startActivity(Intent.createChooser(send, getString(R.string.share_chooser)));
            });
        }).start();
    }
}
