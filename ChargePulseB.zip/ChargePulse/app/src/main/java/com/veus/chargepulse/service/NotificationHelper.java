package com.veus.chargepulse.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.veus.chargepulse.MainActivity;
import com.veus.chargepulse.R;

public final class NotificationHelper {
    /** v2 channel: the old low-importance "monitor" channel cannot be upgraded once created. */
    public static final String CH_MONITOR = "monitor_live";
    private static final String CH_MONITOR_LEGACY = "monitor";
    public static final String CH_ALERTS = "alerts";
    public static final int ID_MONITOR = 1001;

    private NotificationHelper() { }

    public static void createChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        nm.deleteNotificationChannel(CH_MONITOR_LEGACY);
        NotificationChannel monitor = new NotificationChannel(
                CH_MONITOR, c.getString(R.string.ch_monitor), NotificationManager.IMPORTANCE_DEFAULT);
        monitor.setShowBadge(false);
        monitor.setSound(null, null);          // prominent in the shade, but silent
        monitor.enableVibration(false);
        monitor.enableLights(false);
        monitor.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(monitor);

        NotificationChannel alerts = new NotificationChannel(
                CH_ALERTS, c.getString(R.string.ch_alerts), NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(alerts);
    }

    private static PendingIntent openApp(Context c) {
        Intent open = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static Notification monitor(Context c, String text) {
        Intent stop = new Intent(c, MonitorService.class).setAction(MonitorService.ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(c, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent repost = new Intent(c, MonitorService.class).setAction(MonitorService.ACTION_REPOST);
        PendingIntent repostPi = PendingIntent.getService(c, 2, repost,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new NotificationCompat.Builder(c, CH_MONITOR)
                .setSmallIcon(R.drawable.ic_stat_bolt)
                .setContentTitle(c.getString(R.string.notif_title))
                .setContentText(text)
                .setColor(ContextCompat.getColor(c, R.color.cp_cyan))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDeleteIntent(repostPi)   // swiped away (Android 14+ allows it) -> put it straight back
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .setContentIntent(openApp(c))
                .addAction(0, c.getString(R.string.notif_stop), stopPi)
                .build();
        n.flags |= Notification.FLAG_ONGOING_EVENT | Notification.FLAG_NO_CLEAR;
        return n;
    }

    /** False when notifications, or this channel, are switched off, so the user cannot see it. */
    public static boolean isVisible(Context c) {
        if (!NotificationManagerCompat.from(c).areNotificationsEnabled()) return false;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = nm == null ? null : nm.getNotificationChannel(CH_MONITOR);
            if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) return false;
        }
        return true;
    }

    /** Opens the most specific system screen where the user can turn the notification back on. */
    public static Intent settingsIntent(Context c) {
        Intent i;
        if (Build.VERSION.SDK_INT >= 26) {
            if (NotificationManagerCompat.from(c).areNotificationsEnabled()) {
                i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, CH_MONITOR);
            } else {
                i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            }
            i.putExtra(Settings.EXTRA_APP_PACKAGE, c.getPackageName());
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + c.getPackageName()));
        }
        return i;
    }

    public static void updateMonitor(Context c, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(ID_MONITOR, monitor(c, text));
    }

    public static void alert(Context c, int id, String title, String text) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                c, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification n = new NotificationCompat.Builder(c, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat_bolt)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setColor(ContextCompat.getColor(c, R.color.cp_amber))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .setContentIntent(openApp(c))
                .build();
        nm.notify(id, n);
    }
}
