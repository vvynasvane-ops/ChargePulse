package com.veus.chargepulse.ar;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/**
 * Tracks how far the phone has turned (yaw) and tilted (pitch) since the last recenter().
 * Uses the game rotation vector (gyro + accel, no compass drift) with a rotation-vector fallback.
 * Axes are remapped so the back camera is the "forward" direction when the phone is held upright.
 */
public final class PoseTracker implements SensorEventListener {
    private final SensorManager sm;
    private final Sensor sensor;
    private final float[] r = new float[9];
    private final float[] r2 = new float[9];
    private final float[] o = new float[3];
    private volatile float yaw, pitch, yaw0, pitch0;
    private boolean has;

    public PoseTracker(Context c) {
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        Sensor s = null;
        if (sm != null) {
            s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
            if (s == null) s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        }
        sensor = s;
    }

    public boolean isAvailable() {
        return sensor != null;
    }

    public void start() {
        if (sensor != null) sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    public void stop() {
        if (sm != null) sm.unregisterListener(this);
        has = false;
    }

    /** Makes the current direction the origin. */
    public void recenter() {
        yaw0 = yaw;
        pitch0 = pitch;
    }

    /** Radians turned since recenter(); positive = turned right. */
    public float dYaw() {
        return wrap(yaw - yaw0);
    }

    /** Radians tilted since recenter(); positive = looking further down. */
    public float dPitch() {
        return pitch - pitch0;
    }

    private static float wrap(float a) {
        while (a > Math.PI) a -= (float) (2 * Math.PI);
        while (a < -Math.PI) a += (float) (2 * Math.PI);
        return a;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(r, e.values);
        SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2);
        SensorManager.getOrientation(r2, o);
        float ny = o[0];
        float np = o[1];
        if (!has) {
            yaw = ny;
            pitch = np;
            yaw0 = ny;
            pitch0 = np;
            has = true;
        } else {
            yaw = yaw + wrap(ny - yaw) * 0.35f;
            pitch = pitch + (np - pitch) * 0.35f;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}
