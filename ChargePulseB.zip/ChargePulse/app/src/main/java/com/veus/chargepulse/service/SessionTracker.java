package com.veus.chargepulse.service;

import android.content.Context;

import com.veus.chargepulse.battery.BatterySample;
import com.veus.chargepulse.data.Session;
import com.veus.chargepulse.data.SessionDb;
import com.veus.chargepulse.data.StreakStore;
import com.veus.chargepulse.widget.WidgetUpdater;

/** Groups consecutive samples into charge or drain sessions and saves them to the database. */
final class SessionTracker {
    private static final long MIN_DURATION_MS = 60_000L;

    private static final long STREAK_MIN_MS = 5 * 60_000L;

    private final Context ctx;
    private final SessionDb db;
    private int type = -1;
    private long startMs;
    private long lastMs;
    private int startLevel;
    private int lastLevel;
    private double sumMa;
    private double sumW;
    private double sumTemp;
    private int n;
    private float peakMa;
    private float maxTemp;

    SessionTracker(Context c) {
        this.ctx = c.getApplicationContext();
        this.db = SessionDb.get(c);
    }

    void onSample(BatterySample s) {
        int t = s.isPlugged() ? Session.CHARGE : Session.DISCHARGE;
        if (t != type) {
            finish();
            begin(t, s);
        }
        lastMs = s.timeMs;
        lastLevel = s.level;
        if (s.currentSupported) {
            sumMa += s.currentMa;
            sumW += s.powerW();
            sumTemp += s.tempC;
            n++;
            peakMa = Math.max(peakMa, Math.abs(s.currentMa));
            maxTemp = Math.max(maxTemp, s.tempC);
        }
    }

    private void begin(int t, BatterySample s) {
        type = t;
        startMs = s.timeMs;
        startLevel = s.level;
        lastLevel = s.level;
        lastMs = s.timeMs;
        sumMa = 0;
        sumW = 0;
        sumTemp = 0;
        n = 0;
        peakMa = 0;
        maxTemp = 0;
    }

    void finish() {
        if (type >= 0 && n > 0 && lastMs - startMs >= MIN_DURATION_MS) {
            Session s = new Session();
            s.type = type;
            s.startMs = startMs;
            s.endMs = lastMs;
            s.startLevel = startLevel;
            s.endLevel = lastLevel;
            s.avgMa = (float) (sumMa / n);
            s.peakMa = peakMa;
            s.avgPowerW = (float) (sumW / n);
            s.avgTempC = (float) (sumTemp / n);
            s.maxTempC = maxTemp;
            try {
                db.insert(s);
                if (type == Session.CHARGE && lastMs - startMs >= STREAK_MIN_MS) {
                    StreakStore.record(ctx, StreakStore.PTS_CHARGE);
                    WidgetUpdater.updateAll(ctx);
                }
            } catch (RuntimeException ignored) {
                // never let a storage problem stop monitoring
            }
        }
        type = -1;
    }
}
