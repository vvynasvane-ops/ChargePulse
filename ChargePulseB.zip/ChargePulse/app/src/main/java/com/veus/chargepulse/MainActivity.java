package com.veus.chargepulse;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.veus.chargepulse.data.Prefs;
import com.veus.chargepulse.service.MonitorService;
import com.veus.chargepulse.service.NotificationHelper;
import com.veus.chargepulse.ui.ConsumersFragment;
import com.veus.chargepulse.ui.HistoryFragment;
import com.veus.chargepulse.ui.LiveFragment;
import com.veus.chargepulse.ui.SettingsFragment;
import com.veus.chargepulse.ui.TesterFragment;

public class MainActivity extends AppCompatActivity {

    private final ActivityResultLauncher<String> notificationPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                permissionPending = false;
                askBatteryOptimisationOnce();
            });

    private boolean permissionPending;
    private AlertDialog notifDialog, battDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.nav);
        if (savedInstanceState == null) {
            // Select and show Live before any listener exists, so it is built in this frame
            nav.setSelectedItemId(R.id.nav_live);
            show(R.id.nav_live, true);
        }
        nav.setOnItemSelectedListener(item -> {
            show(item.getItemId(), false);
            return true;
        });
        nav.setOnItemReselectedListener(item -> { });

        // Everything non-essential waits until the first frame has been drawn.
        getWindow().getDecorView().post(() -> {
            ensureMonitorRunning();
            if (!askNotificationPermissionOnce()) askBatteryOptimisationOnce();
        });
    }

    private void show(int id, boolean immediate) {
        Fragment f;
        if (id == R.id.nav_test) {
            f = new TesterFragment();
        } else if (id == R.id.nav_history) {
            f = new HistoryFragment();
        } else if (id == R.id.nav_power) {
            f = new ConsumersFragment();
        } else if (id == R.id.nav_settings) {
            f = new SettingsFragment();
        } else {
            f = new LiveFragment();
        }
        androidx.fragment.app.FragmentTransaction tx = getSupportFragmentManager().beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.container, f);
        if (immediate) tx.commitNow(); else tx.commit();
    }

    /** Background monitoring is on by default; only the Stop buttons turn it off. */
    private void ensureMonitorRunning() {
        if (!new Prefs(this).monitorEnabled() || MonitorService.isRunning()) return;
        try {
            ContextCompat.startForegroundService(this, new Intent(this, MonitorService.class));
        } catch (RuntimeException ignored) {
            // can be retried from the Live tab
        }
    }

    /** Returns true when the system permission dialog was launched. */
    private boolean askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33) return false;
        Prefs prefs = new Prefs(this);
        if (prefs.notifAsked()) return false;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            prefs.setNotifAsked(true);
            permissionPending = true;
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
            return true;
        }
        return false;
    }

    private void askBatteryOptimisationOnce() {
        Prefs prefs = new Prefs(this);
        if (prefs.battAsked() || isFinishing()) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
        prefs.setBattAsked(true);
        battDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.bg_title)
                .setMessage(R.string.bg_message)
                .setPositiveButton(R.string.bg_allow, (d, w) -> requestUnrestricted())
                .setNegativeButton(R.string.bg_later, null)
                .create();
        battDialog.setOnDismissListener(d -> checkNotificationVisible());
        battDialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkNotificationVisible();
    }

    /** The monitoring notification must stay visible: while it is hidden, keep asking to fix it. */
    private void checkNotificationVisible() {
        if (isFinishing() || permissionPending) return;
        Prefs prefs = new Prefs(this);
        if (!prefs.monitorEnabled()) return;
        if (Build.VERSION.SDK_INT >= 33 && !prefs.notifAsked()) return; // first launch: permission prompt comes first
        if (battDialog != null && battDialog.isShowing()) return;
        if (NotificationHelper.isVisible(this)) {
            if (notifDialog != null && notifDialog.isShowing()) notifDialog.dismiss();
            return;
        }
        if (notifDialog != null && notifDialog.isShowing()) return;
        notifDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.notif_off_title)
                .setMessage(R.string.notif_off_message)
                .setPositiveButton(R.string.notif_off_fix, (d, w) -> {
                    try {
                        startActivity(NotificationHelper.settingsIntent(this));
                    } catch (ActivityNotFoundException ignored) {
                        // no settings screen available
                    }
                })
                .setNegativeButton(R.string.bg_later, null)
                .show();
    }

    private void requestUnrestricted() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (ActivityNotFoundException ignored) {
                // no settings screen on this device
            }
        }
    }
}
