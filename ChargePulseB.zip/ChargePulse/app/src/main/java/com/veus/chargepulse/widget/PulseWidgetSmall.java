package com.veus.chargepulse.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

/** 2x2 widget: live current, charger verdict, battery bar and the last 7 streak days. */
public class PulseWidgetSmall extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        WidgetUpdater.updateAll(c);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (i != null && WidgetUpdater.ACTION_REFRESH.equals(i.getAction())) {
            WidgetUpdater.updateAll(c);
        }
    }
}
