package com.veus.chargepulse.ar;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;

import java.util.Collections;

/** Minimal Camera2 back-camera preview into a TextureView (portrait, centre-crop, torch). */
final class CameraController {
    interface Callback {
        void onState(boolean running, boolean flashAvailable);

        void onError();
    }

    private final Context ctx;
    private final TextureView view;
    private final Callback cb;
    private final Handler main = new Handler(Looper.getMainLooper());

    private HandlerThread thread;
    private Handler bg;
    private CameraDevice device;
    private CameraCaptureSession session;
    private CaptureRequest.Builder builder;
    private boolean wantOpen, flash, torch;
    private int pw, ph;

    CameraController(Context ctx, TextureView view, Callback cb) {
        this.ctx = ctx.getApplicationContext();
        this.view = view;
        this.cb = cb;
    }

    void start() {
        if (thread != null) return;
        wantOpen = true;
        thread = new HandlerThread("cp-camera");
        thread.start();
        bg = new Handler(thread.getLooper());
        view.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) { open(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { applyTransform(); }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });
        if (view.isAvailable()) open();
    }

    void stop() {
        wantOpen = false;
        view.setSurfaceTextureListener(null);
        try {
            if (session != null) session.close();
            if (device != null) device.close();
        } catch (RuntimeException ignored) {
            // already closed
        }
        session = null;
        device = null;
        builder = null;
        if (thread != null) {
            thread.quitSafely();
            thread = null;
            bg = null;
        }
    }

    /** Returns the new torch state (false when the phone has no flash). */
    boolean toggleTorch() {
        if (!flash) return false;
        torch = !torch;
        if (bg != null) bg.post(this::repeat);
        return torch;
    }

    private void open() {
        if (!wantOpen || device != null) return;
        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            CameraCharacteristics chosen = null;
            for (String s : cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(s);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    id = s;
                    chosen = cc;
                    break;
                }
            }
            if (id == null) { fail(); return; }
            StreamConfigurationMap map = chosen.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) { fail(); return; }
            Size size = choose(map.getOutputSizes(SurfaceTexture.class), view.getWidth(), view.getHeight());
            pw = size.getWidth();
            ph = size.getHeight();
            Boolean f = chosen.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            flash = f != null && f;
            applyTransform();
            cm.openCamera(id, stateCb, bg);
        } catch (CameraAccessException | SecurityException | IllegalArgumentException e) {
            fail();
        }
    }

    private final CameraDevice.StateCallback stateCb = new CameraDevice.StateCallback() {
        @Override public void onOpened(CameraDevice d) {
            if (!wantOpen) { d.close(); return; }
            device = d;
            startPreview();
        }

        @Override public void onDisconnected(CameraDevice d) {
            d.close();
            device = null;
        }

        @Override public void onError(CameraDevice d, int error) {
            d.close();
            device = null;
            fail();
        }
    };

    private void startPreview() {
        try {
            SurfaceTexture st = view.getSurfaceTexture();
            if (st == null || device == null) return;
            st.setDefaultBufferSize(pw, ph);
            Surface surface = new Surface(st);
            builder = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(surface);
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            device.createCaptureSession(Collections.singletonList(surface),
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            if (device == null) return;
                            session = s;
                            repeat();
                            main.post(() -> cb.onState(true, flash));
                        }

                        @Override public void onConfigureFailed(CameraCaptureSession s) { fail(); }
                    }, bg);
        } catch (CameraAccessException | IllegalStateException e) {
            fail();
        }
    }

    private void repeat() {
        try {
            if (session == null || builder == null) return;
            builder.set(CaptureRequest.FLASH_MODE,
                    torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            session.setRepeatingRequest(builder.build(), null, bg);
        } catch (CameraAccessException | IllegalStateException ignored) {
            // session closed while toggling
        }
    }

    private void fail() {
        main.post(cb::onError);
    }

    /** Sensor buffers are landscape; the portrait view shows them rotated, so scale to cover. */
    private void applyTransform() {
        int vw = view.getWidth();
        int vh = view.getHeight();
        if (vw == 0 || vh == 0 || pw == 0 || ph == 0) return;
        float k = Math.max(vw / (float) ph, vh / (float) pw);
        Matrix m = new Matrix();
        m.setScale(ph * k / vw, pw * k / vh, vw / 2f, vh / 2f);
        view.setTransform(m);
    }

    private static Size choose(Size[] sizes, int vw, int vh) {
        double target = (double) Math.max(vw, vh) / Math.max(1, Math.min(vw, vh));
        Size best = null;
        double bestDiff = 1e9;
        for (Size s : sizes) {
            if (s.getWidth() > 1920 || s.getWidth() < 640) continue;
            double diff = Math.abs((double) s.getWidth() / s.getHeight() - target);
            boolean closer = diff < bestDiff - 0.01;
            boolean tieBigger = Math.abs(diff - bestDiff) <= 0.01 && best != null && s.getWidth() > best.getWidth();
            if (best == null || closer || tieBigger) {
                best = s;
                bestDiff = diff;
            }
        }
        return best != null ? best : sizes[0];
    }
}
