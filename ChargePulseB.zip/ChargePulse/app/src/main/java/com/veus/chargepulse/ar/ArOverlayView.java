package com.veus.chargepulse.ar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.veus.chargepulse.R;
import com.veus.chargepulse.battery.BatterySample;
import com.veus.chargepulse.ui.Fmt;

import java.util.Random;

/**
 * Holographic HUD drawn over the camera preview.
 * - Energy particles stream into the reticle while charging (out while draining), faster with current.
 * - After "lock" the reticle and four data panels are pinned in space: the phone's yaw/pitch is
 *   converted to a pixel shift, and each panel has its own depth so they parallax against each other.
 * - A radar sweep and progress ring run during the scan, then a verdict badge and sparks appear.
 */
public class ArOverlayView extends View {
    public static final int IDLE = 0, SCANNING = 1, RESULT = 2;

    /** Flip a sign here if the pinned HUD moves the wrong way on a given device. */
    private static final float YAW_SIGN = -1f, PITCH_SIGN = -1f;
    private static final float HFOV = (float) Math.toRadians(63);
    private static final int N = 48, SPARKS = 40;

    private final Random rnd = new Random();
    private final float dp;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vignette = new Paint();
    private final RectF rect = new RectF();
    private final int cDim, cText, cRed, cAmber;
    private final String lblCur, lblPow, lblTmp, lblVol, lblAvgCur, lblAvgPow, lblRise, lblPeak;
    private final Drawable flame;

    private PoseTracker pose;
    private int mode = IDLE;
    private float progress;
    private int accent;
    private BatterySample live;
    private float offX, offY, t, resultT;
    private long lastNs;

    private final float[] pAng = new float[N], pRad = new float[N], pSpd = new float[N];
    private final float[] sAng = new float[SPARKS], sSpd = new float[SPARKS];
    private final float[] sDist = new float[SPARKS], sLife = new float[SPARKS];

    private String vCur = "\u2014", vPow = "\u2014", vTmp = "\u2014", vVol = "\u2014";
    private int tmpColor;
    private String verdict = "", pill = "";
    private int verdictColor;
    private String rSub = "";

    public ArOverlayView(Context c) {
        this(c, null);
    }

    public ArOverlayView(Context c, AttributeSet a) {
        super(c, a);
        dp = c.getResources().getDisplayMetrics().density;
        cDim = ContextCompat.getColor(c, R.color.cp_dim);
        cText = ContextCompat.getColor(c, R.color.cp_text);
        cRed = ContextCompat.getColor(c, R.color.cp_red);
        cAmber = ContextCompat.getColor(c, R.color.cp_amber);
        accent = ContextCompat.getColor(c, R.color.cp_cyan);
        tmpColor = cText;
        lblCur = c.getString(R.string.tag_current);
        lblPow = c.getString(R.string.tag_power);
        lblTmp = c.getString(R.string.tag_temp);
        lblVol = c.getString(R.string.tag_voltage);
        lblAvgCur = c.getString(R.string.tag_avg_current);
        lblAvgPow = c.getString(R.string.tag_avg_power);
        lblRise = c.getString(R.string.tag_temp_rise);
        lblPeak = c.getString(R.string.tag_peak);

        text.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        Drawable d = ContextCompat.getDrawable(c, R.drawable.ic_flame);
        flame = d == null ? null : d.mutate();
        for (int i = 0; i < N; i++) respawn(i, true, true);
    }

    // ---- API used by ScanActivity -------------------------------------------------------

    public void attachPose(PoseTracker p) {
        pose = p;
    }

    public void setLive(BatterySample s, int color) {
        live = s;
        accent = color;
        if (mode != RESULT) {
            vCur = s.currentSupported ? Fmt.ma(s.currentMa) : "\u2014";
            vPow = s.currentSupported ? Fmt.watts(s.powerW()) : "\u2014";
            vTmp = Fmt.temp(s.tempC);
            vVol = Fmt.volts(s.voltageMv);
            tmpColor = s.tempC >= 42f ? cRed : s.tempC >= 38f ? cAmber : cText;
        }
    }

    public void setMode(int m) {
        mode = m;
        resultT = 0f;
        if (m != SCANNING) progress = 0f;
        if (m == IDLE && live != null) setLive(live, accent);
    }

    public void setProgress(float p) {
        progress = Math.max(0f, Math.min(1f, p));
    }

    public void setResult(float avgMa, float peakMa, float avgW, float rise,
                          String verdictText, int verdictCol, int streak, int xp, boolean extended) {
        mode = RESULT;
        resultT = 0f;
        verdict = verdictText;
        verdictColor = verdictCol;
        vCur = Fmt.ma(avgMa);
        vPow = Fmt.watts(avgW);
        vTmp = String.format(java.util.Locale.US, "%+.1f \u00B0C", rise);
        tmpColor = rise >= 6f ? cRed : rise >= 3f ? cAmber : cText;
        vVol = Fmt.maAbs(peakMa);
        rSub = Fmt.ma(avgMa) + "  \u00B7  " + Fmt.watts(avgW);
        pill = getContext().getString(extended ? R.string.scan_pill_new : R.string.scan_pill_kept,
                extended ? streak : xp, xp);
        for (int i = 0; i < SPARKS; i++) {
            sAng[i] = rnd.nextFloat() * 6.2831855f;
            sSpd[i] = (120f + rnd.nextFloat() * 260f) * dp;
            sDist[i] = 0f;
            sLife[i] = 0.6f + rnd.nextFloat() * 0.6f;
        }
    }

    // ---- drawing -------------------------------------------------------------------------

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        vignette.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * 0.75f,
                new int[]{0x00000000, 0x00000000, 0xAA000000}, new float[]{0f, 0.55f, 1f},
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas cv) {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) return;

        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        t += dt;
        if (mode == RESULT) resultT += dt;

        // world -> screen shift
        float f = (w / 2f) / (float) Math.tan(HFOV / 2f);
        float tx = 0f, ty = 0f;
        if (mode != IDLE && pose != null && pose.isAvailable()) {
            tx = clamp(YAW_SIGN * pose.dYaw() * f, -w, w);
            ty = clamp(PITCH_SIGN * pose.dPitch() * f, -h, h);
        }
        float k = 1f - (float) Math.exp(-dt * (mode == IDLE ? 6f : 16f));
        offX += (tx - offX) * k;
        offY += (ty - offY) * k;

        float ax = w / 2f + offX;
        float ay = h * 0.40f + offY;
        float r = Math.min(w, h) * 0.15f;

        cv.drawRect(0, 0, w, h, vignette);
        drawBrackets(cv, w, h);
        updateParticles(dt);
        drawParticles(cv, ax, ay, r);
        drawTags(cv, w, ax, ay, r);
        drawReticle(cv, ax, ay, r);
        if (mode == RESULT) drawResult(cv, w, ax, ay, r);
        drawSparks(cv, ax, ay, dt);

        postInvalidateOnAnimation();
    }

    private void drawBrackets(Canvas cv, int w, int h) {
        float l = 24 * dp, len = 26 * dp, top = 96 * dp, bottom = h - 175 * dp, right = w - l;
        stroke.setStrokeWidth(2.5f * dp);
        stroke.setColor(alpha(accent, 140));
        cv.drawLine(l, top, l + len, top, stroke);
        cv.drawLine(l, top, l, top + len, stroke);
        cv.drawLine(right, top, right - len, top, stroke);
        cv.drawLine(right, top, right, top + len, stroke);
        cv.drawLine(l, bottom, l + len, bottom, stroke);
        cv.drawLine(l, bottom, l, bottom - len, stroke);
        cv.drawLine(right, bottom, right - len, bottom, stroke);
        cv.drawLine(right, bottom, right, bottom - len, stroke);
    }

    private boolean inward() {
        return live == null || !live.currentSupported || live.currentMa >= 0f;
    }

    private void respawn(int i, boolean anywhere, boolean in) {
        pAng[i] = rnd.nextFloat() * 6.2831855f;
        pSpd[i] = 0.25f + rnd.nextFloat() * 0.5f;
        pRad[i] = anywhere ? rnd.nextFloat() : (in ? 1f : 0.05f);
    }

    private void updateParticles(float dt) {
        float flow = (live != null && live.currentSupported)
                ? clamp(Math.abs(live.currentMa) / 1500f, 0.15f, 2.2f) : 0.3f;
        boolean in = inward();
        for (int i = 0; i < N; i++) {
            pRad[i] += (in ? -1f : 1f) * pSpd[i] * flow * dt;
            if (pRad[i] < 0.05f || pRad[i] > 1f) respawn(i, false, in);
        }
    }

    private void drawParticles(Canvas cv, float ax, float ay, float r) {
        float field = r * 2.5f;
        float trail = inward() ? 0.07f : -0.07f;
        stroke.setStrokeWidth(2.2f * dp);
        for (int i = 0; i < N; i++) {
            float ca = (float) Math.cos(pAng[i]);
            float sa = (float) Math.sin(pAng[i]);
            float r1 = pRad[i];
            float r2 = r1 + trail;
            int a = (int) (200f * Math.sin(Math.PI * clamp(r1, 0f, 1f)));
            stroke.setColor(alpha(accent, a));
            cv.drawLine(ax + ca * r1 * field, ay + sa * r1 * field,
                    ax + ca * r2 * field, ay + sa * r2 * field, stroke);
        }
    }

    private void drawTags(Canvas cv, int w, float ax, float ay, float r) {
        float tw = Math.min(w * 0.31f, 138 * dp);
        float th = 54 * dp;
        float gx = tw / 2f + r * 0.95f;
        float gy = r * 1.15f;
        boolean res = mode == RESULT;
        tag(cv, ax, ay, -gx, -gy, 1.12f, res ? lblAvgCur : lblCur, vCur, accent, tw, th);
        tag(cv, ax, ay, gx, -gy * 0.8f, 0.92f, res ? lblAvgPow : lblPow, vPow, accent, tw, th);
        tag(cv, ax, ay, -gx, gy, 0.85f, res ? lblRise : lblTmp, vTmp, tmpColor, tw, th);
        tag(cv, ax, ay, gx, gy * 1.15f, 1.2f, res ? lblPeak : lblVol, vVol, cText, tw, th);
    }

    private void tag(Canvas cv, float ax, float ay, float dx, float dy, float depth,
                     String label, String value, int vColor, float tw, float th) {
        float cx = ax + dx + (depth - 1f) * offX * 0.9f;
        float cy = ay + dy + (depth - 1f) * offY * 0.9f;

        stroke.setStrokeWidth(1.2f * dp);
        stroke.setColor(alpha(vColor, 110));
        cv.drawLine(ax, ay, cx, cy, stroke);

        rect.set(cx - tw / 2f, cy - th / 2f, cx + tw / 2f, cy + th / 2f);
        fill.setColor(0xD90A0F1A);
        cv.drawRoundRect(rect, 12 * dp, 12 * dp, fill);
        stroke.setColor(alpha(vColor, 150));
        cv.drawRoundRect(rect, 12 * dp, 12 * dp, stroke);

        text.setTextAlign(Paint.Align.LEFT);
        text.setLetterSpacing(0.08f);
        text.setColor(cDim);
        text.setTextSize(9.5f * dp);
        cv.drawText(label, rect.left + 10 * dp, rect.top + 18 * dp, text);
        text.setLetterSpacing(0f);
        text.setColor(vColor);
        text.setTextSize(15f * dp);
        cv.drawText(value, rect.left + 10 * dp, rect.bottom - 11 * dp, text);
    }

    private void drawReticle(Canvas cv, float ax, float ay, float r) {
        boolean scanning = mode == SCANNING;
        stroke.setStrokeCap(Paint.Cap.ROUND);

        // expanding idle ping
        if (mode == IDLE) {
            float ph = (t * 0.8f) % 1f;
            stroke.setStrokeWidth(2f * dp);
            stroke.setColor(alpha(accent, (int) (120 * (1f - ph))));
            cv.drawCircle(ax, ay, r * (1f + 0.4f * ph), stroke);
        }

        stroke.setStrokeWidth(2f * dp);
        stroke.setColor(alpha(accent, 90));
        cv.drawCircle(ax, ay, r, stroke);

        float rot = t * (scanning ? 140f : 35f);
        stroke.setStrokeWidth(4f * dp);
        stroke.setColor(accent);
        rect.set(ax - r * 1.18f, ay - r * 1.18f, ax + r * 1.18f, ay + r * 1.18f);
        for (int i = 0; i < 4; i++) cv.drawArc(rect, rot + i * 90f, 48f, false, stroke);

        stroke.setStrokeWidth(1.5f * dp);
        stroke.setColor(alpha(accent, 170));
        rect.set(ax - r * 0.62f, ay - r * 0.62f, ax + r * 0.62f, ay + r * 0.62f);
        for (int i = 0; i < 6; i++) cv.drawArc(rect, -rot * 1.6f + i * 60f, 20f, false, stroke);

        stroke.setStrokeWidth(1.5f * dp);
        stroke.setColor(alpha(cText, 160));
        for (int i = 0; i < 4; i++) {
            float ang = (float) (i * Math.PI / 2);
            float c = (float) Math.cos(ang), s = (float) Math.sin(ang);
            cv.drawLine(ax + c * r * 0.28f, ay + s * r * 0.28f, ax + c * r * 0.45f, ay + s * r * 0.45f, stroke);
        }

        fill.setColor(accent);
        cv.drawCircle(ax, ay, (4f + 1.8f * (float) Math.sin(t * 5f)) * dp, fill);

        if (scanning) {
            float sweep = (t * 200f) % 360f;
            rect.set(ax - r, ay - r, ax + r, ay + r);
            for (int i = 0; i < 8; i++) {
                fill.setColor(alpha(accent, 70 - i * 8));
                cv.drawArc(rect, sweep - i * 6f, 6f, true, fill);
            }
            stroke.setStrokeWidth(6f * dp);
            stroke.setColor(accent);
            rect.set(ax - r * 0.92f, ay - r * 0.92f, ax + r * 0.92f, ay + r * 0.92f);
            cv.drawArc(rect, -90f, 360f * progress, false, stroke);
        }
    }

    private void drawResult(Canvas cv, int w, float ax, float ay, float r) {
        float s = easeOutBack(Math.min(1f, resultT / 0.45f));
        float bw = Math.min(w * 0.82f, 320 * dp);
        float bh = 84 * dp;
        float top = ay + r * 1.33f + 41 * dp;
        float cy = top + bh / 2f;

        cv.save();
        cv.scale(s, s, ax, cy);
        rect.set(ax - bw / 2f, top, ax + bw / 2f, top + bh);
        fill.setColor(0xE60A0F1A);
        cv.drawRoundRect(rect, 18 * dp, 18 * dp, fill);
        stroke.setStrokeWidth(2f * dp);
        stroke.setColor(verdictColor);
        cv.drawRoundRect(rect, 18 * dp, 18 * dp, stroke);

        text.setTextAlign(Paint.Align.CENTER);
        text.setColor(verdictColor);
        text.setTextSize(26f * dp);
        cv.drawText(verdict.toUpperCase(java.util.Locale.US), ax, top + 38 * dp, text);
        text.setColor(cText);
        text.setTextSize(13f * dp);
        cv.drawText(rSub, ax, top + 64 * dp, text);

        // streak pill
        float pillTop = top + bh + 10 * dp;
        text.setTextSize(12.5f * dp);
        float tw = text.measureText(pill);
        float pw = tw + 52 * dp;
        rect.set(ax - pw / 2f, pillTop, ax + pw / 2f, pillTop + 32 * dp);
        fill.setColor(0xE60A0F1A);
        cv.drawRoundRect(rect, 16 * dp, 16 * dp, fill);
        stroke.setStrokeWidth(1.5f * dp);
        stroke.setColor(cAmber);
        cv.drawRoundRect(rect, 16 * dp, 16 * dp, stroke);
        if (flame != null) {
            flame.setTint(cAmber);
            int fx = (int) (rect.left + 10 * dp);
            int fy = (int) (pillTop + 6 * dp);
            flame.setBounds(fx, fy, fx + (int) (20 * dp), fy + (int) (20 * dp));
            flame.draw(cv);
        }
        text.setTextAlign(Paint.Align.LEFT);
        text.setColor(cText);
        cv.drawText(pill, rect.left + 36 * dp, pillTop + 21 * dp, text);
        cv.restore();
    }

    private void drawSparks(Canvas cv, float ax, float ay, float dt) {
        if (mode != RESULT) return;
        for (int i = 0; i < SPARKS; i++) {
            if (sLife[i] <= 0f) continue;
            sDist[i] += sSpd[i] * dt;
            sLife[i] -= dt * 0.9f;
            if (sLife[i] <= 0f) continue;
            fill.setColor(alpha(i % 2 == 0 ? verdictColor : cText, (int) (255 * Math.min(1f, sLife[i]))));
            cv.drawCircle(ax + (float) Math.cos(sAng[i]) * sDist[i],
                    ay + (float) Math.sin(sAng[i]) * sDist[i], 3f * dp * sLife[i], fill);
        }
    }

    // ---- helpers -------------------------------------------------------------------------

    private static int alpha(int color, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (color & 0x00FFFFFF);
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static float easeOutBack(float x) {
        float c1 = 1.70158f;
        float c3 = c1 + 1f;
        float p = x - 1f;
        return 1f + c3 * p * p * p + c1 * p * p;
    }
}
