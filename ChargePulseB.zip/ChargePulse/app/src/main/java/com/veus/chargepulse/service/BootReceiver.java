package com.veus.chargepulse.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

import com.veus.chargepulse.data.Prefs;
import com.veus.chargepulse.widget.WidgetUpdater;

/** Restarts background monitoring after a reboot or an app update, unless the user stopped it. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) return;
        WidgetUpdater.updateAll(c);
        if (!new Prefs(c).monitorEnabled()) return;
        try {
            ContextCompat.startForegroundService(c, new Intent(c, MonitorService.class));
        } catch (RuntimeException ignored) {
            // the system refused a background start; the app will resume monitoring when opened
        }
    }
}
