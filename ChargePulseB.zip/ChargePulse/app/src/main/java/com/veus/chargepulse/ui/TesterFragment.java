package com.veus.chargepulse.ui;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.veus.chargepulse.R;
import com.veus.chargepulse.battery.BatteryReader;
import com.veus.chargepulse.battery.BatterySample;
import com.veus.chargepulse.battery.Classifier;
import com.veus.chargepulse.data.Session;
import com.veus.chargepulse.data.SessionDb;
import com.veus.chargepulse.data.StreakStore;
import com.veus.chargepulse.widget.WidgetUpdater;

public class TesterFragment extends Fragment {
    private static final int WARMUP_S = 3;
    private static final int[] DURATIONS_S = {15, 20, 30};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BatteryReader reader;

    private EditText etLabel;
    private Spinner spDuration;
    private MaterialButton btnStart;
    private ProgressBar progress;
    private TextView tvLive, tvVerdict, tvResult, tvBest;
    private MaterialCardView cardResult;

    private boolean running;
    private int elapsed;
    private int measureSeconds;
    private double sumMa;
    private double sumW;
    private int n;
    private float peakMa;
    private float startTemp;
    private float maxTemp;
    private int startLevel;
    private long startMs;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running || !isAdded() || getView() == null) return;
            step();
            if (running) handler.postDelayed(this, 1000L);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_tester, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        Context c = requireContext();
        reader = new BatteryReader(c);

        etLabel = v.findViewById(R.id.etLabel);
        spDuration = v.findViewById(R.id.spDuration);
        btnStart = v.findViewById(R.id.btnStartTest);
        progress = v.findViewById(R.id.progress);
        tvLive = v.findViewById(R.id.tvTestLive);
        tvVerdict = v.findViewById(R.id.tvVerdict);
        tvResult = v.findViewById(R.id.tvResult);
        tvBest = v.findViewById(R.id.tvBest);
        cardResult = v.findViewById(R.id.cardResult);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                c, R.array.test_durations, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDuration.setAdapter(adapter);
        spDuration.setSelection(1);

        btnStart.setOnClickListener(b -> {
            if (running) {
                stopTest(null);
            } else {
                startTest();
            }
        });
        showBest();
    }

    @Override
    public void onPause() {
        if (running) stopTest(null);
        handler.removeCallbacksAndMessages(null);
        super.onPause();
    }

    private void startTest() {
        BatterySample s = reader.read();
        if (!s.isPlugged()) {
            Toast.makeText(requireContext(), R.string.test_need_plug, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!s.currentSupported) {
            Toast.makeText(requireContext(), R.string.test_unsupported, Toast.LENGTH_LONG).show();
            return;
        }
        int idx = Math.max(0, Math.min(spDuration.getSelectedItemPosition(), DURATIONS_S.length - 1));
        measureSeconds = DURATIONS_S[idx];
        elapsed = 0;
        sumMa = 0;
        sumW = 0;
        n = 0;
        peakMa = 0;
        startTemp = s.tempC;
        maxTemp = s.tempC;
        startLevel = s.level;
        startMs = System.currentTimeMillis();
        running = true;

        cardResult.setVisibility(View.GONE);
        progress.setMax(WARMUP_S + measureSeconds);
        progress.setProgress(0);
        progress.setVisibility(View.VISIBLE);
        btnStart.setText(R.string.btn_cancel_test);
        handler.postDelayed(tick, 1000L);
    }

    private void step() {
        BatterySample s = reader.read();
        if (!s.isPlugged()) {
            stopTest(getString(R.string.test_unplugged));
            return;
        }
        elapsed++;
        progress.setProgress(elapsed);
        maxTemp = Math.max(maxTemp, s.tempC);

        if (elapsed <= WARMUP_S) {
            tvLive.setText(getString(R.string.test_warmup, WARMUP_S - elapsed + 1));
            return;
        }
        sumMa += s.currentMa;
        sumW += s.powerW();
        n++;
        peakMa = Math.max(peakMa, Math.abs(s.currentMa));
        int left = WARMUP_S + measureSeconds - elapsed;
        tvLive.setText(getString(R.string.test_running, Fmt.ma(s.currentMa), left));

        if (left <= 0) {
            finishTest(s);
        }
    }

    private void stopTest(@Nullable String message) {
        running = false;
        handler.removeCallbacks(tick);
        if (!isAdded() || getView() == null) return;
        progress.setVisibility(View.INVISIBLE);
        btnStart.setText(R.string.btn_start_test);
        tvLive.setText(message == null ? "" : message);
    }

    private void finishTest(BatterySample last) {
        running = false;
        handler.removeCallbacks(tick);
        Context c = requireContext();
        progress.setVisibility(View.INVISIBLE);
        btnStart.setText(R.string.btn_start_test);
        tvLive.setText("");
        if (n == 0) return;

        float avgMa = (float) (sumMa / n);
        float avgW = (float) (sumW / n);
        int rating = Classifier.rate(avgMa);

        tvVerdict.setText(Classifier.labelRes(rating));
        tvVerdict.setTextColor(ContextCompat.getColor(c, Classifier.colorRes(rating)));
        tvResult.setText(getString(R.string.test_result,
                Fmt.ma(avgMa), Fmt.maAbs(peakMa), avgW,
                Fmt.temp(maxTemp), String.format(java.util.Locale.US, "%+.1f \u00B0C", maxTemp - startTemp)));
        cardResult.setVisibility(View.VISIBLE);

        String label = etLabel.getText().toString().trim();
        Session sess = new Session();
        sess.type = Session.TEST;
        sess.label = label.isEmpty() ? getString(R.string.unlabeled) : label;
        sess.startMs = startMs;
        sess.endMs = System.currentTimeMillis();
        sess.startLevel = startLevel;
        sess.endLevel = last.level;
        sess.avgMa = avgMa;
        sess.peakMa = peakMa;
        sess.avgPowerW = avgW;
        sess.avgTempC = (startTemp + maxTemp) / 2f;
        sess.maxTempC = maxTemp;
        try {
            SessionDb.get(c).insert(sess);
            StreakStore.record(c, StreakStore.PTS_TEST);
            WidgetUpdater.updateAll(c);
            Toast.makeText(c, R.string.test_saved, Toast.LENGTH_SHORT).show();
        } catch (RuntimeException ignored) {
            // result is still shown on screen
        }
        showBest();
    }

    private void showBest() {
        Session best;
        try {
            best = SessionDb.get(requireContext()).bestTest();
        } catch (RuntimeException e) {
            best = null;
        }
        if (best == null) {
            tvBest.setText(R.string.test_best_none);
        } else {
            tvBest.setText(getString(R.string.test_best, best.label, Fmt.ma(best.avgMa)));
        }
    }
}
