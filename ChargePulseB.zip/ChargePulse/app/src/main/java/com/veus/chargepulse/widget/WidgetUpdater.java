package com.veus.chargepulse.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.widget.RemoteViews;

import androidx.core.content.ContextCompat;

import com.veus.chargepulse.MainActivity;
import com.veus.chargepulse.R;
import com.veus.chargepulse.ar.ScanActivity;
import com.veus.chargepulse.battery.BatteryReader;
import com.veus.chargepulse.battery.BatterySample;
import com.veus.chargepulse.battery.Classifier;
import com.veus.chargepulse.data.Prefs;
import com.veus.chargepulse.data.StreakStore;
import com.veus.chargepulse.ui.Fmt;

import java.util.Locale;

/** Builds and pushes RemoteViews for both home-screen widgets. */
public final class WidgetUpdater {
    public static final String ACTION_REFRESH = "com.veus.chargepulse.action.WIDGET_REFRESH";

    private static final int[] DOTS = {R.id.wd0, R.id.wd1, R.id.wd2, R.id.wd3, R.id.wd4, R.id.wd5, R.id.wd6};
    private static long lastPush;

    private WidgetUpdater() { }

    /** Cheap to call from a sampling loop: does nothing if called again within minGapMs. */
    public static void updateThrottled(Context c, long minGapMs) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastPush < minGapMs) return;
        lastPush = now;
        updateAll(c);
    }

    public static void updateAll(Context c) {
        try {
            Context app = c.getApplicationContext();
            AppWidgetManager mgr = AppWidgetManager.getInstance(app);
            int[] small = mgr.getAppWidgetIds(new ComponentName(app, PulseWidgetSmall.class));
            int[] wide = mgr.getAppWidgetIds(new ComponentName(app, PulseWidgetWide.class));
            if (small.length == 0 && wide.length == 0) return;

            BatterySample b = new BatteryReader(app).read();
            StreakStore.Snapshot st = StreakStore.snapshot(app);
            Prefs prefs = new Prefs(app);
            if (small.length > 0) mgr.updateAppWidget(small, build(app, b, st, prefs, false));
            if (wide.length > 0) mgr.updateAppWidget(wide, build(app, b, st, prefs, true));
        } catch (RuntimeException ignored) {
            // a widget glitch must never crash the caller
        }
    }

    private static RemoteViews build(Context c, BatterySample b, StreakStore.Snapshot st,
                                     Prefs prefs, boolean wide) {
        RemoteViews rv = new RemoteViews(c.getPackageName(),
                wide ? R.layout.widget_wide : R.layout.widget_small);
        int color = Fmt.stateColor(c, b, prefs);

        // current
        rv.setTextViewText(R.id.wCurrent, b.currentSupported
                ? String.format(Locale.US, "%+,d", Math.round(b.currentMa))
                : c.getString(R.string.not_available));
        rv.setTextColor(R.id.wCurrent, color);

        // state line
        String state;
        if (b.isPlugged() && b.currentSupported) {
            String rate = c.getString(Classifier.shortRes(Classifier.rate(b.currentMa)))
                    .toUpperCase(Locale.US);
            state = wide ? c.getString(R.string.widget_state_charging, rate) : rate;
        } else if (b.isPlugged()) {
            state = c.getString(R.string.widget_state_plugged);
        } else {
            state = c.getString(R.string.widget_state_battery);
        }
        rv.setTextViewText(R.id.wState, state);
        rv.setTextColor(R.id.wState, color);

        // meta
        String meta = wide
                ? "mA \u00B7 " + Fmt.watts(b.powerW()) + " \u00B7 " + Fmt.volts(b.voltageMv)
                + " \u00B7 " + Fmt.temp(b.tempC)
                : "mA \u00B7 " + String.format(Locale.US, "%.1f W", b.powerW());
        rv.setTextViewText(R.id.wMeta, meta);

        // level bar
        rv.setProgressBar(R.id.wLevelBar, 100, Math.max(0, b.level), false);

        // streak
        rv.setTextViewText(R.id.wStreak, String.valueOf(st.streak));
        int green = ContextCompat.getColor(c, R.color.cp_green);
        int cyan = ContextCompat.getColor(c, R.color.cp_cyan);
        int dim = ContextCompat.getColor(c, R.color.cp_stroke);
        for (int i = 0; i < 7; i++) {
            rv.setTextColor(DOTS[i], st.week[i] == 1 ? green : st.week[i] == 2 ? cyan : dim);
        }

        if (wide) {
            String[] names = c.getResources().getStringArray(R.array.streak_levels);
            rv.setTextViewText(R.id.wLevelName, c.getString(R.string.streak_label,
                    names[Math.min(st.level, names.length - 1)], st.level + 1));
            rv.setTextViewText(R.id.wStreakSub, c.getString(st.doneToday
                    ? R.string.widget_streak_done : R.string.widget_streak_sub));
            rv.setOnClickPendingIntent(R.id.wScan, activity(c, 11, ScanActivity.class));
        }

        rv.setOnClickPendingIntent(R.id.wRoot, activity(c, 10, MainActivity.class));
        Intent refresh = new Intent(c, PulseWidgetSmall.class).setAction(ACTION_REFRESH);
        rv.setOnClickPendingIntent(R.id.wRefresh, PendingIntent.getBroadcast(c, 12, refresh,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        return rv;
    }

    private static PendingIntent activity(Context c, int code, Class<?> cls) {
        Intent i = new Intent(c, cls).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
}
