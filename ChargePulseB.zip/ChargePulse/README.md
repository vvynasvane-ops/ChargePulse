# ChargePulse

Battery current / charger tester for Android. Pure Java + XML (no Kotlin, no Compose, no Room, no kapt).
Only three libraries: AppCompat, Core, Material.

## Build (Windows CMD)

    clean_build.bat        (clean + assembleDebug)
    build.bat              (assembleDebug)

Manual equivalent:

    gradlew.bat clean
    gradlew.bat clean assembleDebug
    gradlew.bat assembleDebug

APK: app\build\outputs\apk\debug\app-debug.apk

`setup.bat` (called automatically) downloads gradle-wrapper.jar 8.10.2 if it is missing and writes
local.properties if it is missing. Edit local.properties if your SDK is somewhere else.

## Toolchain

- Gradle 8.10.2 (first Gradle line that runs on JDK 23)
- Android Gradle Plugin 8.7.3
- compileSdk / targetSdk 34, minSdk 24, Java 17 source level

## Screens

- Live: current (mA), power (W), voltage, temperature, level, time estimate, rolling chart, peak/average, health, background monitor toggle
- Tester: timed charger/cable test with verdict, label and auto-save, best-so-far
- History: charge / drain / test sessions, CSV share, long-press to delete
- Power: system snapshot, top apps by 24 h screen time (needs Usage access), shortcuts to Android settings
- Settings: unit and sign override, sampling interval, alert thresholds, device diagnostics

## AR scanner, streaks and widgets

- **AR scan** (Live tab card, or the wide widget): Camera2 preview with a holographic HUD. Aim at the
  charger and tap SCAN; after a 2 s warm-up it averages 8 s of current. Readout panels are pinned in
  space with the gyro (each at its own depth, so they parallax), particles flow into the phone faster
  with more current, and the verdict badge, History entry, streak and widgets all update. Share exports
  a snapshot image. Without the camera permission the HUD still works over a dark background.
- **Pulse streak**: a day counts for 5+ min of charging, a Tester run or an AR scan. Every 7th day banks a
  freeze (max 2) that covers one missed day. Points (charge 10, test 25, scan 40) climb Spark, Trickle,
  Flow, Surge, Dynamo, Stormcaller, Tesla.
- **Widgets**: "Pulse" (2x2) and "Pulse + Streak" (4x2). They refresh every 6 s while the monitor service
  runs, instantly on plug/unplug, and on tap of the refresh glyph; otherwise Android's 30 min minimum applies.

## Known limits

- CURRENT_NOW accuracy depends on the phone's fuel gauge. Use Settings > Device diagnostics to check the raw value.
- Per-app battery drain is not exposed to normal apps, so screen time is used as a proxy.
- Foreground service type is specialUse. A Play Store release needs a declaration for it.
